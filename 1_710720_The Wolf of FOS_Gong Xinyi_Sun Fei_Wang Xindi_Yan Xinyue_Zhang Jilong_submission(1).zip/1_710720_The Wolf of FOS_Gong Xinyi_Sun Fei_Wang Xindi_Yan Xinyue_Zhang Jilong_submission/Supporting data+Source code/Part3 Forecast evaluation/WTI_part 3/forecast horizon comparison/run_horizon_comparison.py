import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
root=Path(__file__).resolve().parent
src=root/'fair_metrics.csv'
if not src.exists(): src=Path('/mnt/data/fair_metrics.csv')
df=pd.read_csv(src)
t=df[df['split'].str.lower().eq('test')].copy()
base=t[t.model=='RandomWalk'][['horizon','RMSE','MSE']].rename(columns={'RMSE':'RW_RMSE','MSE':'RW_MSE'})
t=t.merge(base,on='horizon',validate='many_to_one')
t['RMSE_improvement_pct']=100*(1-t.RMSE/t.RW_RMSE)
t['OOS_R2_pct']=100*(1-t.MSE/t.RW_MSE)
t.to_csv(root/'all_test_metrics_with_benchmark.csv',index=False)
t.pivot(index='model',columns='horizon',values='RMSE').round(5).to_csv(root/'rmse_1_5_20_60.csv')
t.pivot(index='model',columns='horizon',values='Direction_Accuracy').mul(100).round(3).to_csv(root/'directional_accuracy_1_5_20_60.csv')
t.loc[t.groupby('horizon')['RMSE'].idxmin(),['horizon','model','RMSE','n_common']].sort_values('horizon').to_csv(root/'best_models_by_horizon.csv',index=False)
models=['RandomWalk','HistoricalMean','ARIMA(1,1,0)','FactorVAE+MLP','RandomForest','GRU+MLP','XGBoost']
colors=['#24558A','#7F8EA3','#E67E22','#17A398','#C94D4D','#8265B6','#B79B42']
fig,axs=plt.subplots(2,2,figsize=(13,8.5));
for ax,h in zip(axs.flat,[1,5,20,60]):
 sub=t[(t.horizon==h)&t.model.isin(models)].sort_values('RMSE',ascending=False)
 ax.barh(sub.model,sub.RMSE,color=[colors[models.index(m)] for m in sub.model]);ax.set_title(f'{h}-day horizon (test n={int(sub.n_common.iloc[0])})');ax.set_xlabel('RMSE (USD/barrel)');ax.grid(axis='x',alpha=.16)
 for y,v in enumerate(sub.RMSE):ax.text(v+.02,y,f'{v:.2f}',va='center',fontsize=8)
 ax.set_xlim(0,sub.RMSE.max()*1.18)
fig.suptitle('Fold 1 | Out-of-sample RMSE by forecast horizon',fontsize=16);fig.tight_layout();fig.savefig(root/'rmse_comparison.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(10,5.5))
for m,c in zip(models[1:],colors[1:]):
 sub=t[t.model==m].sort_values('horizon');ax.plot(sub.horizon,sub.RMSE_improvement_pct,'o-',label=m,color=c)
ax.axhline(0,color='gray',ls='--');ax.set_xticks([1,5,20,60]);ax.set_xlabel('Forecast horizon (trading days)');ax.set_ylabel('RMSE improvement vs Random Walk (%)');ax.set_title('Fold 1 | Relative forecast accuracy (higher is better)');ax.legend(ncol=2,fontsize=9);ax.grid(alpha=.2);fig.tight_layout();fig.savefig(root/'benchmark_improvement.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(10,5.5))
for m,c in zip(models[1:],colors[1:]):
 sub=t[t.model==m].sort_values('horizon');ax.plot(sub.horizon,100*sub.Direction_Accuracy,'o-',label=m,color=c)
ax.axhline(50,color='gray',ls='--',label='50% reference');ax.set_xticks([1,5,20,60]);ax.set_xlabel('Forecast horizon (trading days)');ax.set_ylabel('Directional accuracy (%)');ax.set_title('Fold 1 | Directional accuracy (test set)');ax.legend(ncol=2,fontsize=9);ax.grid(alpha=.2);fig.tight_layout();fig.savefig(root/'directional_accuracy.png',dpi=180);plt.close(fig)
print('BEST MODELS')
print(t.loc[t.groupby('horizon')['RMSE'].idxmin(),['horizon','model','RMSE']].sort_values('horizon').to_string(index=False))
print('\nRANDOM FOREST IMPROVEMENT')
print(t[t.model=='RandomForest'][['horizon','RMSE_improvement_pct','Direction_Accuracy']].to_string(index=False))
