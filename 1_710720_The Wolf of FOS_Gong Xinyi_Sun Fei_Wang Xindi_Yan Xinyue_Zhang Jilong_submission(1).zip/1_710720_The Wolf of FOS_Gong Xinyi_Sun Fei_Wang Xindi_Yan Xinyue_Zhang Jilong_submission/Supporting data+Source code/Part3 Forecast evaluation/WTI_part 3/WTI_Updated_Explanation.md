# WTI Forecast Evaluation — Updated Explanation

## 1. Scope and comparability / 数据范围

**Pooled experiment:** `walkforward_predictions(2).csv` and `walkforward_pooled_fair_metrics(2).csv`; five rolling test folds (2022–2026), 1- and 5-day horizons only. The October 2026 fold is a short partial period. Its results should not be treated as a complete calendar year.

**Horizon extension:** newly uploaded `fair_metrics.csv`; **Fold 1 test split only**, 1-, 5-, 20- and 60-day horizons. The supplied file has model-level aggregated metrics, not observation-level errors for these longer horizons. Accordingly, a 20-/60-day DM/HAC significance test or multi-fold temporal robustness analysis **cannot be calculated from this file alone**.

All reported RMSE values refer to the same price-scale unit (USD/barrel), but pooled and Fold 1 figures describe different samples and must not be merged or presented as if they were the same experiment.

## 2. Forecast accuracy / 预测精度

### Five-fold pooled test, 1D and 5D

| Model | 1D RMSE | 5D RMSE |
|---|---:|---:|
| Random Walk | **1.9691** | **4.3240** |
| Historical Mean | 1.9691 | 4.3246 |
| ARIMA(1,1,0) | 1.9726 | 4.3243 |
| FactorVAE+MLP | 1.9726 | 4.3589 |
| Random Forest | 2.0004 | 4.4251 |

**Interpretation:** Random Walk is the lowest-RMSE pooled model at both horizons. ARIMA is nearly indistinguishable numerically; the sophisticated models listed do not achieve a lower pooled RMSE. The comparison does not by itself prove equality or significance.

### Fold 1 test, 1D / 5D / 20D / 60D

| Model | 1D | 5D | 20D | 60D |
|---|---:|---:|---:|---:|
| Random Walk | 3.0333 | 6.5916 | 10.7087 | 15.9575 |
| Historical Mean | **3.0332** | 6.5897 | 10.6816 | 15.6279 |
| ARIMA(1,1,0) | 3.0413 | 6.5922 | 10.7110 | 15.9575 |
| FactorVAE+MLP | 3.0347 | 6.6016 | 10.6286 | 16.9194 |
| Random Forest | 3.0617 | **6.5561** | **10.5018** | **13.7665** |

**Interpretation:** The leading model changes with forecast horizon. Historical Mean leads at 1D; Random Forest leads at 5D, 20D, and 60D. These are *within-Fold-1* rankings and cannot replace the five-fold pooled ranking. Comparing the raw RMSE magnitude across horizons is not a fair measure of how model quality changes because each horizon predicts a different target.

## 3. Benchmark comparison / 基准改善率

The RMSE improvement over Random Walk is `100 × (1 − RMSE_model / RMSE_RW)`; positive values mean lower RMSE than RW.

**Five-fold pooled:** ARIMA −0.179% (1D) and −0.008% (5D); FactorVAE+MLP −0.181% and −0.808%; Random Forest −1.591% and −2.337%. None of these models improves pooled RMSE over RW.

**Fold 1:** Random Forest improvement is approximately −0.94% (1D), **+0.54% (5D), +1.93% (20D), and +13.73% (60D)**. This is strong *descriptive* evidence of a longer-horizon advantage in one particular fold. It is not yet evidence of statistical significance or temporal robustness.

**Why the two 5D conclusions differ:** pooled results include five folds and aggregate their errors; the horizon-extension file covers Fold 1 only. A model may win one year and still lose overall.

## 4. Directional accuracy / 涨跌方向

Fold 1 Random Forest directional accuracy is **50.80%, 61.38%, 58.87%, and 73.82%** at 1D, 5D, 20D, and 60D respectively. This should be evaluated separately from RMSE. A model can correctly predict the sign while making large magnitude errors.

The 60-day result requires caution: adjacent rolling 60-day forecasts overlap substantially, and a predominantly rising/falling test period can make raw directional accuracy look high. A majority-direction baseline and HAC-adjusted directional inference would require aligned underlying prediction records. A strict-sign Random Walk direction score is not a useful up/down benchmark because Random Walk predicts zero price change.

## 5. Robustness and statistical significance / 稳健性与显著性

Five-fold pooled DM-style HAC comparisons against Random Walk (paired squared-error loss, initial bandwidth h−1):

| Comparison | 1D p-value | 5D p-value |
|---|---:|---:|
| ARIMA | 0.0761 | 0.8837 |
| FactorVAE+MLP | 0.2492 | 0.1449 |
| Random Forest | 0.0676 | 0.2257 |

None reaches the 5% significance threshold. A non-significant result does **not** establish equivalence. The inference is preliminary and depends on HAC bandwidth, overlapping observations, fold transitions, and multiple-testing considerations. **These p-values cannot be applied to Fold 1's 20D/60D forecasts.**

For 20D and 60D significance tests, request date-aligned actual and predicted prices for every model and Random Walk. For long-horizon temporal robustness, request the corresponding 20D and 60D results from additional rolling test folds.

## 6. Final conclusion / 综合结论

**中文：** 五轮汇总实验显示，Random Walk 在 1 日和 5 日预测中具有最优或最具竞争力的误差表现，ARIMA 与之非常接近。新增的四期限单轮测试则发现，Random Forest 在 5、20、60 日预测中优于 Random Walk，尤其 60 日 RMSE 降低约 13.73%。这两组结果并不矛盾，因为测试样本范围不同。当前证据支持“模型表现具有预测期限和样本时期依赖性”，但尚不足以断言 Random Forest 在长期预测中具有普遍且统计显著的优势。

**English presentation-ready conclusion:** *Our five-fold pooled results favor Random Walk at one- and five-day horizons, with ARIMA performing almost identically. In a separate Fold 1 comparison across one, five, twenty and sixty days, Random Forest delivers the lowest RMSE at the three longer horizons, including a 13.73% improvement over Random Walk at sixty days. These findings highlight horizon- and sample-dependence rather than universal model superiority. Further long-horizon rolling tests and HAC-adjusted significance checks are needed before generalizing the Fold 1 advantage.*

## Suggested presentation structure

1. Evaluation scope: pooled five-fold vs Fold 1 extension.
2. Pooled 1D/5D accuracy.
3. Fold 1 four-horizon RMSE.
4. Fold 1 relative RMSE improvement.
5. Fold 1 directional accuracy.
6. Temporal robustness and pooled DM/HAC results.
7. Overall conclusion and limitations.

## Data provenance

User-provided `walkforward_predictions(2).csv`, `walkforward_pooled_fair_metrics(2).csv`, `fair_metrics.csv`, and their derived tables/figures. No external market claims are needed for the findings above.
