# WTI Forecast Evaluation — Revised Experiment (2022–2026)

## Scope and reproducibility

The evaluation uses the uploaded `walkforward_predictions(2).csv` as the authoritative observation-level source. Only `split == test` is used for out-of-sample conclusions. Predictions cover 1- and 5-trading-day horizons, 13 models, and five rolling test folds: 2022, 2023, 2024, 2025, and October 2026. All price errors are measured in USD/barrel. The pooled test sets contain 1,017 origins at 1 day and 997 origins at 5 days. The fifth fold contains only 16 and 12 origins respectively; it must not be interpreted as a full year.

**Data-quality finding:** `walkforward_metrics_by_fold.csv` disagrees with `fair_metrics_5(1).csv` on some fifth-fold entries. For example, the fold-5 5-day validation Random Walk RMSE is 3.0604 in `walkforward_metrics_by_fold.csv`, but 6.7257 in `fair_metrics_5(1).csv`; direct recalculation from daily predictions confirms **6.7257**. Accordingly, all charts and findings are regenerated from observation-level predictions, and `00_fold_discrepancies.csv` documents the conflicts.

## 1. Forecast accuracy

Random Walk is the lowest-RMSE model at both horizons: **1.9691** (1D) and **4.3240** (5D). ARIMA(1,1,0) is close at 1.9726 and 4.3243. FactorVAE+MLP scores 1.9726 and 4.3589, while Random Forest scores 2.0004 and 4.4251. This is evidence that greater complexity did not improve the pooled out-of-sample RMSE in the revised experiment. Lower MAE/RMSE is better, but a difference in the third decimal place is not by itself evidence of statistical significance.

## 2. Benchmark comparison

Relative RMSE improvement is defined as `100 × (1 − RMSE_model / RMSE_RandomWalk)`. Negative means worse than Random Walk. ARIMA: **−0.179% (1D)** and **−0.008% (5D)**. FactorVAE+MLP: **−0.181%** and **−0.808%**. Random Forest: **−1.591%** and **−2.337%**. The out-of-sample R² versus Random Walk is also negative for all three models at both horizons. Thus, none demonstrates a positive pooled error reduction versus the random-walk baseline.

## 3. Directional accuracy

Directional accuracy measures whether the sign of predicted h-day price change matches the sign of the realized h-day price change. Random Forest achieves **52.61% (1D)** and **54.26% (5D)**; FactorVAE+MLP achieves **51.52%** and **52.96%**; ARIMA achieves **50.54%** and **50.15%**. This metric must be interpreted separately from RMSE: a model may predict direction relatively well while predicting magnitudes poorly. Random Walk forecasts zero price change, so its near-zero strict-sign DA is a *definition artifact*, not a meaningful up/down forecasting benchmark. The supplied code constructs a separate majority-direction reference using each fold's validation observations only; inspect `04_majority_direction.csv`.

## 4. Temporal robustness

The figures `04_temporal.png` and table `03_yearly.csv` show fold-specific RMSE. Four full-year folds and one short October 2026 fold should be distinguished. A pooled RMSE can be disproportionately affected by a high-error year because errors are squared. Model rankings can change over time, and the fifth fold's small sample means its estimates are especially uncertain. The experiment does not support a claim that any sophisticated model consistently dominates the random walk across folds.

## 5. Statistical significance

The script computes a two-sided DM-style comparison of paired squared-error differences with Newey–West/Bartlett HAC long-run variance. It excludes lagged covariance terms crossing fold boundaries. Primary bandwidth is `h−1`; additional bandwidths `h` and `2h` are saved for sensitivity checks. At primary bandwidth, ARIMA versus Random Walk has p-values **0.0761 (1D)** and **0.8837 (5D)**; FactorVAE+MLP **0.2492** and **0.1449**; Random Forest **0.0676** and **0.2257**. None of these six comparisons reaches 5% significance. Failure to reject equal average squared loss is not proof of equal forecasting ability. Overlapping 5-day targets, fold boundaries, finite sample sizes, and multiple comparisons remain limitations.

## Final presentation-ready conclusion

> In our revised out-of-sample evaluation, Random Walk delivers the lowest pooled RMSE at both one-day and five-day horizons. ARIMA performs almost identically, whereas FactorVAE+MLP and Random Forest do not consistently improve price forecast accuracy. Some machine-learning models achieve higher directional accuracy, but this does not translate into lower price prediction error. HAC-adjusted loss-differential tests do not establish statistically significant improvements for the principal alternative models. The findings favor parsimonious benchmarks and highlight the importance of evaluating accuracy, direction, temporal stability, and statistical uncertainty separately.

## Output files

`00_fold_discrepancies.csv` — source audit; `01_accuracy.csv` and `01_rmse.png` — accuracy; `02_benchmark.csv` and `02_benchmark.png` — benchmark improvement and OOS R²; `03_direction.png` and `04_majority_direction.csv` — directional evaluation; `03_yearly.csv` and `04_temporal.png` — fold robustness; `05_dm_hac.csv` — DM-style HAC test and bandwidth sensitivity.

## Execution

Install `pandas numpy scipy matplotlib`. Put the three named input CSVs into an `input/` folder next to `run_forecast_evaluation.py` and execute `python run_forecast_evaluation.py`. The original five `fair_metrics` files and `walkforward_metrics_by_fold.csv` can be compared separately with `make_audit.py`.
