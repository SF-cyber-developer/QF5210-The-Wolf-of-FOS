import pandas as pd
from pathlib import Path
r=Path('/mnt/data/wti_final_analysis'); b=pd.read_csv(r/'input/walkforward_metrics_by_fold.csv'); frames=[]
for i in range(1,6):
 a=pd.read_csv(f'/mnt/data/fair_metrics_{i}(1).csv'); q=a.merge(b[b.fold==i],on=['fold','horizon','split','model'],suffixes=('_fair','_by_fold'))
 q['RMSE_abs_diff']=(q.RMSE_fair-q.RMSE_by_fold).abs();frames.append(q)
x=pd.concat(frames);x[x.RMSE_abs_diff>1e-7].to_csv(r/'outputs/00_fold_discrepancies.csv',index=False)
print('discrepancies',len(x[x.RMSE_abs_diff>1e-7]),'by fold',x[x.RMSE_abs_diff>1e-7].groupby('fold').size().to_dict())
