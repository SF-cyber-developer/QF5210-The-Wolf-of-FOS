from pathlib import Path
import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
ROOT=Path(__file__).resolve().parent
INPUT=ROOT/'input'; OUT=ROOT/'outputs'; OUT.mkdir(exist_ok=True)
p=pd.read_csv(INPUT/'walkforward_predictions(2).csv',parse_dates=['Date','realized_date'])
pooled=pd.read_csv(INPUT/'walkforward_pooled_fair_metrics(2).csv')
fold_metrics=pd.read_csv(INPUT/'walkforward_metrics_by_fold.csv')
assert set(p.split)=={'validation','test'}
assert p.duplicated(['fold','split','Date','horizon','model']).sum()==0
assert set(p.target_mode)=={'LOG_RETURN'}
t=p[p.split=='test'].copy()
t['error']=t.actual_price-t.predicted_price
t['squared_error']=t.error**2
t['abs_error']=t.error.abs()
t['hit']=(np.sign(t.predicted_price-t.current_price)==np.sign(t.actual_price-t.current_price)).astype(int)
agg=t.groupby(['horizon','model']).agg(n=('error','size'),MSE=('squared_error','mean'),MAE=('abs_error','mean'),DA=('hit','mean')).reset_index()
agg['RMSE']=np.sqrt(agg.MSE)
check=agg.merge(pooled,on=['horizon','model'],suffixes=('_recalc','_source'))
for col in ['MSE','MAE','RMSE']:
 assert np.max(np.abs(check[col+'_recalc']-check[col+'_source']))<1e-7,(col,np.max(np.abs(check[col+'_recalc']-check[col+'_source'])))
assert np.max(np.abs(check.DA-check.Direction_Accuracy))<1e-7
agg.to_csv(OUT/'01_accuracy.csv',index=False)
base=agg[agg.model=='RandomWalk'][['horizon','RMSE','MSE']].rename(columns={'RMSE':'RW_RMSE','MSE':'RW_MSE'})
b=agg.merge(base,on='horizon');b['RMSE_improvement_pct']=100*(1-b.RMSE/b.RW_RMSE);b['OOS_R2']=1-b.MSE/b.RW_MSE
b.to_csv(OUT/'02_benchmark.csv',index=False)
y=t.groupby(['fold','horizon','model']).agg(n=('error','size'),MSE=('squared_error','mean'),MAE=('abs_error','mean'),DA=('hit','mean')).reset_index();y['RMSE']=np.sqrt(y.MSE)
y.to_csv(OUT/'03_yearly.csv',index=False)
# majority direction fixed using preceding validation observations, no test leakage
v=p[p.split=='validation'].copy();v['actual_sign']=np.sign(v.actual_price-v.current_price)
maj=[]
for (fold,h),z in v[v.model=='RandomWalk'].groupby(['fold','horizon']):
 sign=1 if (z.actual_sign>0).sum()>=(z.actual_sign<0).sum() else -1
 zz=t[(t.fold==fold)&(t.horizon==h)&(t.model=='RandomWalk')]
 maj.append(dict(fold=fold,horizon=h,train_majority_sign=sign,test_n=len(zz),test_DA=float((np.sign(zz.actual_price-zz.current_price)==sign).mean())))
majority=pd.DataFrame(maj);majority.to_csv(OUT/'04_majority_direction.csv',index=False)
# Newey-West Bartlett HAC for paired squared loss differential, test observations sorted within folds
comparisons=['ARIMA(1,1,0)','FactorVAE+MLP','RandomForest','HistoricalMean']
rows=[]
for h in sorted(t.horizon.unique()):
 for m in comparisons:
  z=t[(t.horizon==h)&(t.model.isin(['RandomWalk',m]))]
  wide=z.pivot(index=['fold','Date'],columns='model',values='squared_error').dropna().reset_index().sort_values(['fold','Date'])
  d=wide[m].to_numpy()-wide['RandomWalk'].to_numpy();n=len(d)
  for lag in sorted(set([max(0,h-1),h,2*h])):
   lag=min(lag,n-1); u=d-d.mean(); gamma0=np.dot(u,u)/n; lr=gamma0
   # avoid cross-fold covariance (five independent evaluation blocks)
   folds=wide.fold.to_numpy()
   for k in range(1,lag+1):
    valid=(folds[k:]==folds[:-k]); gamma=np.dot(u[k:][valid],u[:-k][valid])/n
    lr+=2*(1-k/(lag+1))*gamma
   stat=d.mean()/np.sqrt(lr/n) if lr>0 else np.nan
   rows.append(dict(horizon=h,model=m,benchmark='RandomWalk',n=n,HAC_lag=lag,mean_loss_diff=d.mean(),DM_style_stat=stat,p_value=2*norm.sf(abs(stat))))
dm=pd.DataFrame(rows);dm.to_csv(OUT/'05_dm_hac.csv',index=False)
# charts
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
models=['RandomWalk','HistoricalMean','ARIMA(1,1,0)','FactorVAE+MLP','RandomForest','GRU+MLP']
fig,axs=plt.subplots(1,2,figsize=(12,5),layout='constrained')
for ax,h in zip(axs,[1,5]):
 z=agg[(agg.horizon==h)&(agg.model.isin(models))].sort_values('RMSE',ascending=False)
 ax.barh(z.model,z.RMSE,color=['#e66b22' if x=='RandomWalk' else '#164e7a' for x in z.model]);ax.set_title(f'{h}-day forecast');ax.set_xlabel('RMSE (USD/barrel)');ax.set_xlim(0,z.RMSE.max()*1.18)
 for i,vv in enumerate(z.RMSE):ax.text(vv+.025,i,f'{vv:.3f}',va='center',fontsize=9)
fig.savefig(OUT/'01_rmse.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(9,4.6),layout='constrained')
for m in ['ARIMA(1,1,0)','FactorVAE+MLP','RandomForest','HistoricalMean']:
 z=b[b.model==m].sort_values('horizon');ax.plot(z.horizon,z.RMSE_improvement_pct,marker='o',label=m)
ax.axhline(0,color='gray',ls='--');ax.set_xticks([1,5]);ax.set_xlabel('Horizon (trading days)');ax.set_ylabel('RMSE improvement vs Random Walk (%)');ax.legend();fig.savefig(OUT/'02_benchmark.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(9,4.6),layout='constrained')
for m in ['ARIMA(1,1,0)','FactorVAE+MLP','RandomForest','HistoricalMean']:
 z=agg[agg.model==m].sort_values('horizon');ax.plot(z.horizon,100*z.DA,marker='o',label=m)
for h in [1,5]:
 zz=majority[majority.horizon==h]; ax.scatter([h],[100*np.average(zz.test_DA,weights=zz.test_n)],marker='D',color='#c05a25',s=70,zorder=4)
ax.set_xticks([1,5]);ax.set_ylabel('Directional accuracy (%)');ax.set_xlabel('Horizon (days)');ax.legend();fig.savefig(OUT/'03_direction.png',dpi=180);plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(12,4.6),layout='constrained')
for ax,h in zip(axs,[1,5]):
 for m in ['RandomWalk','ARIMA(1,1,0)','FactorVAE+MLP']:
  z=y[(y.horizon==h)&(y.model==m)].sort_values('fold');ax.plot(z.fold,z.RMSE,marker='o',label=m)
 ax.set_title(f'{h}-day RMSE by test fold');ax.set_xlabel('Test fold (2022, 2023, 2024, 2025, Oct 2026)');ax.set_xticks([1,2,3,4,5]);ax.set_ylabel('RMSE (USD/barrel)');ax.legend(fontsize=8)
fig.savefig(OUT/'04_temporal.png',dpi=180);plt.close(fig)
print('Pooled accuracy:\n',agg[agg.model.isin(['RandomWalk','ARIMA(1,1,0)','FactorVAE+MLP','RandomForest'])][['horizon','model','n','RMSE','DA']].to_string(index=False))
print('\nBenchmark:\n',b[b.model.isin(['ARIMA(1,1,0)','FactorVAE+MLP','RandomForest'])][['horizon','model','RMSE_improvement_pct','OOS_R2']].to_string(index=False))
print('\nDM baseline lags:\n',dm[dm.HAC_lag==dm.horizon-1][['horizon','model','p_value']].to_string(index=False))
print('\nFold 5 counts:',y[(y.fold==5)&(y.model=='RandomWalk')][['horizon','n']].to_dict('records'))
