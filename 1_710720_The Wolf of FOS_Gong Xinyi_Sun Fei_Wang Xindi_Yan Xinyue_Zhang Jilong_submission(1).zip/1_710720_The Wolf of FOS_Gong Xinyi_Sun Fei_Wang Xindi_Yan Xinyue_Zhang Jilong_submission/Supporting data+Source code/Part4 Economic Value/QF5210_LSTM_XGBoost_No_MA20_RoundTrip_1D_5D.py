# -*- coding: utf-8 -*-
"""QF5210 Economic Value: LSTM+XGBoost WITHOUT MA20 filter.

Official forecast-origin window: 2026-10-01 to 2026-10-23 inclusive.
Forecast horizons: 1 and 5 trading days.
Trading rule: forecast direction only (Long if predicted return > 0,
Short if predicted return < 0, Cash if exactly zero).
Execution: next available session open to that session close.

Place beside this script:
  RESULTS.zip
  01_WTI&Brent_updated_2026-11-04(2).zip

Run: python QF5210_LSTM_XGBoost_No_MA20_RoundTrip_1D_5D.py
Dependencies: pandas, numpy, matplotlib
"""
from pathlib import Path
import io
import zipfile
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "QF5210_LSTM_XGBoost_No_MA20_roundtrip_results"
OUT.mkdir(parents=True, exist_ok=True)
START = pd.Timestamp("2026-10-01")
END = pd.Timestamp("2026-10-23")
MODEL = "LSTM+XGBoost"
HORIZONS = (1, 5)
COSTS_BPS = (0, 5, 10, 20)  # TOTAL round-trip bps
BASE_COST_BPS = 5  # TOTAL round-trip bps = 2.5 bps per side


def find_file(filename):
    for p in (ROOT / filename, ROOT / "Data" / filename, ROOT / "data" / filename):
        if p.is_file():
            return p
    raise FileNotFoundError(
        f"Cannot find {filename}. Put it beside this .py file."
    )


def read_csv_from_zip(zip_filename, csv_basename):
    zip_path = find_file(zip_filename)
    with zipfile.ZipFile(zip_path, "r") as zf:
        matches = [n for n in zf.namelist()
                   if Path(n).name.lower() == csv_basename.lower()
                   and not n.startswith("__MACOSX/")]
        if len(matches) != 1:
            raise FileNotFoundError(
                f"Expected one {csv_basename} in {zip_filename}; found {matches}"
            )
        return pd.read_csv(io.BytesIO(zf.read(matches[0])))


def load_inputs():
    print("Loading forecast and WTI price data...")
    pred = read_csv_from_zip("RESULTS.zip", "walkforward_predictions.csv")
    price = read_csv_from_zip(
        "01_WTI&Brent_updated_2026-11-04(2).zip",
        "WTI_clean_daily_updated_2026-11-04.csv"
    )
    required_pred = {
        "Date", "realized_date", "model", "horizon", "split",
        "current_price", "actual_price", "predicted_price"
    }
    required_price = {"Date", "CL1_PX_OPEN", "CL1_PX_LAST"}
    miss = required_pred - set(pred.columns)
    if miss:
        raise ValueError(f"Prediction file missing columns: {sorted(miss)}")
    miss = required_price - set(price.columns)
    if miss:
        raise ValueError(f"WTI file missing columns: {sorted(miss)}")

    pred["Date"] = pd.to_datetime(pred["Date"], errors="coerce")
    pred["realized_date"] = pd.to_datetime(pred["realized_date"], errors="coerce")
    pred["horizon"] = pd.to_numeric(pred["horizon"], errors="coerce")
    for c in ("current_price", "actual_price", "predicted_price"):
        pred[c] = pd.to_numeric(pred[c], errors="coerce")
    pred["model"] = pred["model"].astype(str).str.strip()
    pred["split"] = pred["split"].astype(str).str.strip().str.lower()

    price["Date"] = pd.to_datetime(price["Date"], errors="coerce")
    for c in ("CL1_PX_OPEN", "CL1_PX_LAST"):
        price[c] = pd.to_numeric(price[c], errors="coerce")
    price = (price.dropna(subset=["Date"]).sort_values("Date")
             .drop_duplicates("Date", keep="last").set_index("Date"))
    return pred, price


def calc_drawdown(returns):
    r = pd.Series(returns, dtype=float).fillna(0.0)
    equity = (1.0 + r).cumprod()
    path = pd.concat([pd.Series([1.0]), equity.reset_index(drop=True)], ignore_index=True)
    return float((path / path.cummax() - 1.0).min()) if len(path) else np.nan


def calc_stats(returns, positions):
    r = pd.Series(returns, dtype=float).fillna(0.0)
    p = np.asarray(positions, dtype=float)
    equity = (1.0 + r).cumprod()
    sd = r.std(ddof=1)
    sharpe = np.sqrt(252) * r.mean() / sd if len(r) > 1 and sd > 0 else np.nan
    active = p != 0
    return {
        "n_execution_days": len(r),
        "n_active_days": int(active.sum()),
        "n_long_days": int((p == 1).sum()),
        "n_short_days": int((p == -1).sum()),
        "n_cash_days": int((p == 0).sum()),
        "win_rate_active_pct": float((r.to_numpy()[active] > 0).mean() * 100) if active.any() else np.nan,
        "cumulative_net_return_pct": float((equity.iloc[-1] - 1) * 100) if len(equity) else np.nan,
        "sharpe_daily_annualized": float(sharpe) if pd.notna(sharpe) else np.nan,
        "max_drawdown_pct": calc_drawdown(r) * 100,
    }


def official_accuracy(pred):
    # Date is the forecast origin; only targets realized by the test-window end are scored.
    x = pred[(pred["model"] == MODEL) & (pred["split"] == "test")
             & pred["Date"].between(START, END) & pred["horizon"].isin(HORIZONS)].copy()
    x["evaluable_by_test_end"] = (
        x["realized_date"].notna() & (x["realized_date"] <= END)
        & x["actual_price"].notna() & x["predicted_price"].notna()
        & x["current_price"].gt(0) & x["actual_price"].gt(0)
    )
    x["actual_direction"] = np.sign(x["actual_price"] / x["current_price"] - 1)
    x["predicted_direction"] = np.sign(x["predicted_price"] / x["current_price"] - 1)
    rows = []
    for h in HORIZONS:
        g = x[x["horizon"] == h]
        v = g[g["evaluable_by_test_end"]]
        if len(v):
            err = v["predicted_price"] - v["actual_price"]
            mae = err.abs().mean()
            rmse = np.sqrt((err ** 2).mean())
            mape = (err.abs() / v["actual_price"].abs()).mean() * 100
            da = (v["actual_direction"] == v["predicted_direction"]).mean() * 100
        else:
            mae = rmse = mape = da = np.nan
        rows.append({
            "model": MODEL, "horizon_trading_days": h,
            "forecast_origins_in_window": len(g),
            "evaluable_targets_by_2026_10_23": len(v),
            "MAE_price_units": mae, "RMSE_price_units": rmse,
            "MAPE_percent": mape, "directional_accuracy_percent": da,
        })
    x.to_csv(OUT / "official_test_forecast_rows_1D_5D.csv", index=False)
    result = pd.DataFrame(rows)
    result.to_csv(OUT / "official_test_accuracy_1D_5D.csv", index=False)
    return result, x


def make_execution_rows(pred, prices, horizon):
    f = pred[(pred["model"] == MODEL) & (pred["split"] == "test")
             & pred["Date"].between(START, END)
             & (pred["horizon"] == horizon)].copy()
    if f.duplicated(["Date"]).any():
        raise ValueError(f"Duplicate {MODEL} {horizon}D forecasts by origin date")
    f = f.dropna(subset=["Date", "current_price", "predicted_price"]).sort_values("Date")
    dates = prices.index.sort_values()
    locmap = {d: i for i, d in enumerate(dates)}
    rows = []
    audit = []
    for _, r in f.iterrows():
        origin = r["Date"]
        if origin not in locmap:
            audit.append({"origin": origin, "horizon": horizon, "status": "origin_missing_from_price_calendar"})
            continue
        i = locmap[origin]
        if i + 1 >= len(dates):
            audit.append({"origin": origin, "horizon": horizon, "status": "no_next_session"})
            continue
        exec_date = dates[i + 1]
        if exec_date > END:
            audit.append({"origin": origin, "horizon": horizon, "status": "execution_after_test_window"})
            continue
        op = prices.at[exec_date, "CL1_PX_OPEN"]
        cl = prices.at[exec_date, "CL1_PX_LAST"]
        cp = r["current_price"]
        pp = r["predicted_price"]
        if not all(np.isfinite(v) for v in (op, cl, cp, pp)) or min(op, cl, cp) <= 0:
            audit.append({"origin": origin, "horizon": horizon, "status": "missing_or_invalid_price"})
            continue
        predicted_return = pp / cp - 1.0
        # No MA20: trade directly on the model's forecast direction.
        position = 1 if predicted_return > 0 else (-1 if predicted_return < 0 else 0)
        rows.append({
            "forecast_origin": origin,
            "forecast_target_date": r["realized_date"],
            "execution_date": exec_date,
            "model": MODEL,
            "forecast_horizon_trading_days": horizon,
            "current_price": cp,
            "predicted_price": pp,
            "predicted_return": predicted_return,
            "position": position,
            "signal": {1: "Long", -1: "Short", 0: "Cash"}[position],
            "next_open": op,
            "next_close": cl,
            "underlying_intraday_return": cl / op - 1.0,
        })
        audit.append({"origin": origin, "horizon": horizon, "execution_date": exec_date,
                      "position": position, "status": "executed"})
    return pd.DataFrame(rows), audit


def run_economic_value(pred, prices):
    executions = {}
    audit_rows = []
    for h in HORIZONS:
        executions[h], audit = make_execution_rows(pred, prices, h)
        audit_rows.extend(audit)

    pd.DataFrame(audit_rows).to_csv(OUT / "forecast_execution_audit.csv", index=False)
    nonempty = [df for df in executions.values() if not df.empty]
    common = sorted(set.intersection(*[
        set(df["forecast_origin"]) for df in nonempty
    ])) if len(nonempty) == 2 else []

    summaries, daily_rows, trade_rows = [], [], []
    for h, df in executions.items():
        if df.empty:
            continue
        df = df.sort_values("execution_date").copy()
        trade_rows.append(df)
        samples = [("all_available_origins", df)]
        if common:
            samples.append(("matched_common_origins", df[df["forecast_origin"].isin(common)]))
        for sample_name, sample in samples:
            if sample.empty:
                continue
            pos = sample["position"].to_numpy(float)
            underlying = sample["underlying_intraday_return"].to_numpy(float)
            for cost in COSTS_BPS:
                cost_return = (pos != 0) * (cost / 10000.0)  # one entry + exit combined
                net = pos * underlying - cost_return
                stats = calc_stats(net, pos)
                stats.update({"strategy": f"{MODEL}_{h}D_ForecastOnly_NoMA20",
                              "forecast_horizon_trading_days": h,
                              "sample": sample_name, "cost_bps_round_trip": cost})
                summaries.append(stats)
                if cost == BASE_COST_BPS:
                    temp = sample.copy()
                    temp["sample"] = sample_name
                    temp["cost_bps_round_trip"] = cost
                    temp["strategy_return_net"] = net
                    temp["equity"] = np.cumprod(1 + net)
                    daily_rows.append(temp)

    # Benchmarks, using each horizon's same executable calendar.
    for h, df in executions.items():
        if df.empty:
            continue
        df = df.sort_values("execution_date")
        underlying = df["underlying_intraday_return"].to_numpy(float)
        for name, pos in [("Always_Long_Intraday", np.ones(len(df))),
                          ("Cash", np.zeros(len(df)))]:
            net = pos * underlying - (pos != 0) * BASE_COST_BPS / 10000.0
            stats = calc_stats(net, pos)
            stats.update({"strategy": name, "forecast_horizon_trading_days": h,
                          "sample": "all_available_origins", "cost_bps_round_trip": BASE_COST_BPS})
            summaries.append(stats)

    summary = pd.DataFrame(summaries)
    summary.to_csv(OUT / "economic_value_comparison_No_MA20_1D_5D.csv", index=False)
    if trade_rows:
        pd.concat(trade_rows, ignore_index=True).to_csv(
            OUT / "daily_trading_signals_No_MA20_1D_5D.csv", index=False)
    if daily_rows:
        pd.concat(daily_rows, ignore_index=True).to_csv(
            OUT / "daily_equity_cost_sensitivity_No_MA20_1D_5D.csv", index=False)

    # Coverage and direction audit.
    coverage = []
    for h, df in executions.items():
        coverage.append({
            "model": MODEL, "horizon_trading_days": h,
            "executable_forecast_origins": len(df),
            "long_days": int((df["position"] == 1).sum()) if len(df) else 0,
            "short_days": int((df["position"] == -1).sum()) if len(df) else 0,
            "cash_days": int((df["position"] == 0).sum()) if len(df) else 0,
            "first_origin": df["forecast_origin"].min() if len(df) else pd.NaT,
            "last_origin": df["forecast_origin"].max() if len(df) else pd.NaT,
        })
    pd.DataFrame(coverage).to_csv(OUT / "coverage_audit_No_MA20.csv", index=False)

    # Equity chart at base cost.
    if daily_rows:
        dailies = pd.concat(daily_rows, ignore_index=True)
        dailies = dailies[dailies["sample"] == "all_available_origins"]
        fig, ax = plt.subplots(figsize=(11, 6))
        for h in HORIZONS:
            part = dailies[dailies["forecast_horizon_trading_days"] == h]
            if not part.empty:
                ax.plot(part["execution_date"], part["equity"], marker="o", label=f"{h}-Day Forecast Only")
        ax.axhline(1, color="gray", linestyle="--", linewidth=0.9)
        ax.set_title("LSTM+XGBoost Without MA20: 1-Day vs 5-Day Signals (5 bps round-trip)")
        ax.set_xlabel("Execution date")
        ax.set_ylabel("Hypothetical equity (initial = 1)")
        ax.legend(); ax.grid(alpha=0.25); fig.tight_layout()
        fig.savefig(OUT / "equity_1D_vs_5D_No_MA20.png", dpi=200)
        plt.close(fig)

    # Cost sensitivity chart.
    fig, ax = plt.subplots(figsize=(12, 6))
    for h, df in executions.items():
        if df.empty:
            continue
        df = df.sort_values("execution_date")
        pos = df["position"].to_numpy(float)
        underlying = df["underlying_intraday_return"].to_numpy(float)
        for cost in COSTS_BPS:
            net = pos * underlying - (pos != 0) * (cost / 10000.0)
            ax.plot(df["execution_date"], np.cumprod(1 + net), marker="o",
                    label=f"{h}D forecast, {cost} bps round-trip")
    ax.axhline(1, color="gray", linestyle="--", linewidth=0.9)
    ax.set_title("LSTM+XGBoost Without MA20: Transaction-Cost Sensitivity")
    ax.set_xlabel("Execution date")
    ax.set_ylabel("Hypothetical equity (initial = 1)")
    ax.legend(ncol=2, fontsize=8); ax.grid(alpha=0.25); fig.tight_layout()
    fig.savefig(OUT / "cost_sensitivity_No_MA20_1D_5D.png", dpi=200)
    plt.close(fig)
    return summary, executions, common


def main():
    pred, prices = load_inputs()
    print("Forecast rows:", len(pred))
    print("Models:", pred["model"].nunique())
    print("Horizons in file:", sorted(pred["horizon"].dropna().unique().tolist()))
    print(f"Official forecast origins: {START.date()} to {END.date()}")

    accuracy, _ = official_accuracy(pred)
    print("\n=== LSTM+XGBoost OFFICIAL FORECAST ACCURACY ===")
    print(accuracy.to_string(index=False, float_format=lambda v: f"{v:.4f}"))

    summary, executions, common = run_economic_value(pred, prices)
    print("\n=== ECONOMIC VALUE: NO MA20, 5 BPS ROUND-TRIP ===")
    if not summary.empty:
        show = summary[(summary["cost_bps_round_trip"] == BASE_COST_BPS)
                       & (summary["sample"] == "all_available_origins")]
        print(show.to_string(index=False, float_format=lambda v: f"{v:.4f}"))
    print("\nMatched common forecast origins:", len(common))
    print("\nResults saved to:", OUT)
    print("\nInterpretation notes:")
    print("- Signals use forecast direction only; MA20 is NOT used.")
    print("- 1D and 5D forecasts both execute next-session open-to-close.")
    print("- A 5-day forecast does NOT mean a 5-day holding period.")
    print("- Accuracy is scored only when target actuals are available by Oct 23.")
    print("- October results are exploratory because the test window has been inspected.")
    print("- Short-window Sharpe ratios are unstable; no slippage/roll model is included.")


if __name__ == "__main__":
    main()
