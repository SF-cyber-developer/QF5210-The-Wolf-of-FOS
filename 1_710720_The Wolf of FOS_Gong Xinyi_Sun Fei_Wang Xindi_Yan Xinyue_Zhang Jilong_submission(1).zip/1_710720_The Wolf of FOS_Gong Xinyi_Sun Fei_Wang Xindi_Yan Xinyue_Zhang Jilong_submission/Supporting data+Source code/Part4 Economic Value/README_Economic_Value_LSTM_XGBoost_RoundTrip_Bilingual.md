# QF5210 — Part 4: Economic Value / 经济价值评估

**Final analysis configuration / 最终分析设置:** LSTM+XGBoost forecast-only directional strategy (**without MA20**); 1-day and 5-day forecast horizons; **5 bps total round-trip cost** (2.5 bps per side assumed).

## 1. Research objective / 研究目标

**EN.** This optional component investigates whether WTI price forecasts can be converted into economically meaningful trading signals after transaction costs. It compares the 1-day and 5-day LSTM+XGBoost signals, evaluates P&L and risk, and checks whether the forecast strategy adds value beyond simple benchmarks.

**中文。** 本部分研究WTI价格预测能否转化为扣除交易成本后具有经济意义的交易信号。比较LSTM+XGBoost的1日和5日预测信号，计算盈亏与风险，并检验是否优于简单基准策略。

## 2. Data and evaluation window / 数据与评估窗口

- **Official forecast-origin window / 官方预测起点：** 2026-10-01 to 2026-10-23 (inclusive). This specifies when forecasts are issued, **not** the forecast target dates.
- **Forecast horizons / 预测期限：** 1 and 5 trading days. The available file contains 16 and 12 forecast-origin records respectively; their last recorded origins are October 22 and October 16.
- **Price source / 价格来源：** supplied WTI continuous front-month price series, with open and close prices used as a theoretical execution proxy.
- **Accuracy / 准确率：** only targets observable by October 23 are evaluated. Longer unobserved outcomes must not be assigned artificial realized prices.

## 3. Trading strategy / 交易策略

**EN.** For each forecast origin, compare predicted WTI price with the price known at that origin. If predicted return is positive, take a long position; if negative, take a short position; if zero, stay in cash. The backtest enters at the **next available trading session's open** and exits at that session's **close**. No MA20 or other trend filter is used. Both 1-day and 5-day forecasts are used as directional signals for **one-session intraday trading**, not as matching-length holding periods.

**中文。** 在每个预测起点，比较预测价格与当时已知价格：预测上涨做多，预测下跌做空，预测不变则空仓。回测在下一可交易日开盘建仓、当日收盘平仓；**不使用MA20**。1日和5日指预测期限，两者均用于次日日内交易，而非分别持有1日和5日。

Gross intraday return / 日内毛收益率：

`r_gross,t = position_t × (close_t / open_t − 1)`

Net return / 净收益率：

`r_net,t = r_gross,t − 0.0005 × I(position_t ≠ 0)`

Here 0.0005 is **5 bps for the entire entry-and-exit round trip**, not 5 bps per side. Cash incurs no transaction cost. Cumulative equity is `∏(1 + r_net,t)` with initial equity 1.

## 4. Forecast accuracy / 预测准确率

Official-window results from `official_test_accuracy_1D_5D(1).csv`:

| Metric / 指标 | 1-day | 5-day |
|---|---:|---:|
| Forecast origins / 预测起点数 | 16 | 12 |
| Evaluable targets / 可验证目标数 | 16 | 12 |
| MAE (price units) | 1.9164 | 4.3884 |
| RMSE (price units) | 2.2989 | 5.7741 |
| MAPE | 1.9812% | 4.4237% |
| Directional accuracy | 68.75% | 58.33% |

**EN.** Error metrics for different horizons refer to different targets; lower 1-day price error should not be interpreted as a controlled test of identical prediction tasks.

**中文。** 不同期限对应不同预测目标，1日预测误差较低不等于在完全相同的预测任务下证明模型更优。

## 5. Economic performance / 经济绩效

**Base case: 5 bps TOTAL round-trip; each horizon uses its own available execution dates. / 基准：双边合计5 bps；各期限使用自身可用执行日期。**

| Metric / 指标 | 1-day | 5-day |
|---|---:|---:|
| Execution / active days | 16 / 16 | 12 / 12 |
| Long / short days | 16 / 0 | 8 / 4 |
| Active-day win rate | 68.75% | 41.67% |
| Cumulative simulated net return | **+11.58%** | **−4.88%** |
| Annualized daily Sharpe (short-sample estimate) | 5.112 | −2.758 |
| Maximum drawdown | −6.79% | −12.88% |

**EN.** In this short exploratory window, the 1-day strategy earned a positive simulated return while the 5-day strategy lost money. Crucially, **all 16 one-day signals were long**, so its return is identical to the Always-Long Intraday benchmark on the same dates and under the same costs. This sample therefore **does not establish incremental economic value** from the 1-day forecasting signal beyond always being long.

**中文。** 在这一较短的探索性窗口中，1日策略模拟收益为正、5日策略为负。但**1日策略16次信号全部做多**，因此其收益与相同日期、相同成本下的Always-Long Intraday完全一致；**不能据此证明1日预测信号相对简单持续做多具有额外经济价值**。

## 6. Fair-date comparison and benchmarks / 共同日期比较与基准

To control for different date coverage, the output also contains a `matched_common_origins` sample with **12 common forecast origins**.

| Strategy, 5 bps round-trip / 策略 | Full available sample | Matched 12 origins |
|---|---:|---:|
| LSTM+XGBoost 1-day | +11.58% (16 days) | +8.31% |
| LSTM+XGBoost 5-day | −4.88% (12 days) | −4.88% |
| Always-Long, same 1-day calendar | +11.58% | +8.31% |
| Cash | 0.00% | 0.00% |

**EN.** Use the matched-date comparison when drawing conclusions about differences between horizons. The Always-Long benchmark exposes the lack of incremental benefit for the 1-day signal in this window. No MA20-only benchmark is part of this final no-MA20 specification.

**中文。** 比较不同预测期限时，应优先使用共同预测起点样本。Always-Long基准说明本次1日预测没有体现额外收益。本版最终策略不包含MA20过滤，也不应把MA20基准误写成策略组成部分。

## 7. Transaction-cost sensitivity / 交易成本敏感性

**All values below are TOTAL round-trip costs, not per-side costs. / 下列成本均为双边合计，而非单边。**

| Round-trip cost / 双边成本 | 1-day net return | 5-day net return |
|---|---:|---:|
| 0 bps | +12.47% | −4.31% |
| **5 bps** | **+11.58%** | **−4.88%** |
| 10 bps | +10.69% | −5.46% |
| 20 bps | +8.94% | −6.59% |

**EN.** The 1-day simulated return remains positive in these cost scenarios, while the 5-day return remains negative. This is a limited sensitivity check, not a full implementation-cost model.

**中文。** 在上述成本假设下，1日策略仍为正收益、5日策略仍为负收益；但这仅是有限的成本敏感性检验，不等于完整模拟真实交易执行成本。

## 8. Figures / 图表

- `equity_1D_vs_5D_No_MA20.png`: simulated equity comparison at **5 bps round-trip** / 双边5 bps下1日与5日净值对比。
- `cost_sensitivity_No_MA20_1D_5D.png`: 0, 5, 10 and 20 bps **round-trip** sensitivity / 双边交易成本敏感性。

The charts represent **hypothetical**, not live, trading performance. / 图表为理论模拟回测，并非真实实盘业绩。

## 9. Limitations / 局限性

1. **Short window / 短样本：** only 16 and 12 forecast-origin records; annualized Sharpe is highly unstable.
2. **Selection bias / 选择偏差：** the October 2026 window was examined during strategy revisions; revised trading performance is **exploratory**, not an untouched independent out-of-sample result.
3. **Forecast/holding mismatch / 预测与持仓期限不匹配：** 5-day price forecasts are converted into next-session intraday trades.
4. **Futures execution proxy / 期货执行代理：** continuous front-month prices do not fully represent executable contract rolls; slippage, market impact, spread variation, financing and margin constraints are not fully modeled.
5. **Benchmark equivalence / 基准等价：** all 1-day signals are long, so the model does not outperform Always-Long on the same dates.
6. **Coverage / 覆盖范围：** differing available origins require matched-date comparisons; missing longer-horizon outcomes should not be fabricated.

## 10. Reproducibility / 复现方法

Put the following files beside the Python script / 将下列文件放在同一目录：

```text
5210pre/
  QF5210_LSTM_XGBoost_No_MA20_RoundTrip_1D_5D.py
  RESULTS.zip
  01_WTI&Brent_updated_2026-11-04(2).zip
```

Install dependencies / 安装依赖：

```bash
pip install numpy pandas matplotlib
```

Run / 运行：

```bash
python QF5210_LSTM_XGBoost_No_MA20_RoundTrip_1D_5D.py
```

The script creates `QF5210_LSTM_XGBoost_No_MA20_roundtrip_results/` containing forecast accuracy, daily signals, equity, coverage and performance CSVs, and the two PNG figures. / 程序输出预测准确率、交易明细、净值、覆盖审计、绩效CSV及两张PNG图。

**Data provenance / 数据来源：** User-supplied `RESULTS.zip`, updated WTI price ZIP, and the exported result CSVs. Reported metrics are copied from the supplied final **round-trip-cost** output tables, not from earlier per-side-cost runs.

## 11. Conclusion / 结论

**EN.** The 1-day LSTM+XGBoost forecast-only strategy delivered **+11.58%** simulated cumulative net return at **5 bps total round-trip cost**, compared with **−4.88%** for the 5-day strategy. However, the 1-day strategy was identical to Always-Long over the observed period, so these findings demonstrate a short-window difference in simulated trading outcomes, **not proven incremental forecasting value**. Results should be reported as exploratory.

**中文。** 在双边合计5 bps成本下，LSTM+XGBoost无MA20的1日策略模拟累计净收益为**+11.58%**，5日策略为**−4.88%**。但1日策略与持续做多基准完全一致，因此结果仅表明短窗口内不同信号的模拟收益差异，**不能证明预测模型具有独立的增量经济价值**。应明确标注为探索性结果。
