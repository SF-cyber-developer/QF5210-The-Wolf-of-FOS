# 原油期货数据说明

## 一、数据来源

本项目使用 Bloomberg Terminal 导出的原油连续期货历史日度数据，整理为以下两个 CSV 文件：

| 文件名 | 品种 | 合约序列 | 数据日期范围 |
|---|---|---|---|
| `Brent_clean_daily(1).csv` | 布伦特原油（Brent） | `CO1 Comdty`、`CO2 Comdty`、`CO3 Comdty` | 2014-12-31 至 2026-10-19 |
| `WTI_clean_daily(1).csv` | 西得克萨斯中质原油（WTI） | `CL1 Comdty`、`CL2 Comdty`、`CL3 Comdty` | 2014-12-31 至 2026-10-20 |

其中，数字 1、2、3 分别表示第一、第二、第三近月连续期货序列。这些序列不是原油现货价格，也不是某个固定到期月份的单一期货合约。

## 二、变量说明

两个 CSV 均以 `Date` 为日期字段。`CO1`、`CO2`、`CO3` 表示 Brent 的三个连续期货序列；`CL1`、`CL2`、`CL3` 表示 WTI 的三个连续期货序列。以下字段分别适用于对应的合约前缀。

### 1. 原始市场变量

| 字段后缀 | 中文名称 | 说明 |
|---|---|---|
| `PX_LAST` | 收盘/最后价格 | Bloomberg 导出的历史最后价格，原油价格通常以美元/桶计 |
| `PX_OPEN` | 开盘价 | 当日开盘价格 |
| `PX_HIGH` | 最高价 | 当日最高价格 |
| `PX_LOW` | 最低价 | 当日最低价格 |
| `PX_VOLUME` | 成交量 | 期货合约成交量，通常以合约张数计 |
| `OPEN_INT` | 未平仓合约量 | Open Interest，通常以合约张数计 |

例如，`CO1_PX_LAST` 表示 Brent 第一近月连续期货价格；`CL2_OPEN_INT` 表示 WTI 第二近月连续期货未平仓合约量。

### 2. 收益率变量

设 `P_t` 为对应连续期货序列在日期 `t` 的 `PX_LAST`，`P_(t-1)` 为前一个观测日期的价格。

| 数据集 | 字段名称（n = 1、2、3） | 计算定义 | 数据单位 |
|---|---|---|---|
| Brent | `COn_Return_pct` | `100 × (P_t / P_(t-1) − 1)` | 百分数数值，如 `1.5` 表示 1.5% |
| Brent | `COn_Log_Return_pct` | `100 × ln(P_t / P_(t-1))` | 百分数数值 |
| WTI | `CLn_Simple_Return` | `P_t / P_(t-1) − 1` | 小数，如 `0.015` 表示 1.5% |
| WTI | `CLn_Log_Return` | `ln(P_t / P_(t-1))` | 小数 |

对数收益率仅在相关价格均为正数时有定义。**Brent 与 WTI 的收益率存储单位不同**，使用时需区分。

### 3. 期货期限价差变量

| 数据集 | 字段名称 | 定义 | 单位 |
|---|---|---|---|
| Brent | `CO1_CO2_Spread_USD_bbl` | `CO1_PX_LAST − CO2_PX_LAST` | 美元/桶 |
| Brent | `CO2_CO3_Spread_USD_bbl` | `CO2_PX_LAST − CO3_PX_LAST` | 美元/桶 |
| Brent | `CO1_CO3_Spread_USD_bbl` | `CO1_PX_LAST − CO3_PX_LAST` | 美元/桶 |
| WTI | `CL1_CL2_Spread` | `CL1_PX_LAST − CL2_PX_LAST` | 美元/桶 |
| WTI | `CL2_CL3_Spread` | `CL2_PX_LAST − CL3_PX_LAST` | 美元/桶 |
| WTI | `CL1_CL3_Spread` | `CL1_PX_LAST − CL3_PX_LAST` | 美元/桶 |
