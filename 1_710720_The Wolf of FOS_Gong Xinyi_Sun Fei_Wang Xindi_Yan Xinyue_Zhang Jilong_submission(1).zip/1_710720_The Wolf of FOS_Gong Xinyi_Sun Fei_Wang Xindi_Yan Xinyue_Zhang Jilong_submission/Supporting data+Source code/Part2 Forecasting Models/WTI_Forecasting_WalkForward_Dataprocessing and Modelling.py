#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""WTI futures forecasting: walk-forward evaluation and frozen hybrid models.

A standalone forecasting pipeline covering data preparation, feature engineering,
model estimation, walk-forward testing, and performance evaluation.
All code comments and documentation are in English.

Usage:
    python AllData_Frozen_Hybrids_WalkForward_4Targets_PriceMSE_EN.py

Place the three source ZIP archives in DATA_DIR (default: current directory).
Adjust TARGET_MODE, FAST_MODE, and other settings in the configuration section.
"""

try:
    from IPython.display import display
except ImportError:
    def display(obj):
        print(obj)



# ============================================================================
# Environment, configuration, and output paths
# ============================================================================


# ========================================================================
# Part 1: Environment and configuration
# ========================================================================
# ============================================================
# Environment setup.
# ============================================================

# Install required packages before the first run; rerun this script afterward.
# %pip install -U numpy pandas scipy scikit-learn statsmodels xgboost torch matplotlib seaborn nbformat

from pathlib import Path            # Cross-platform filesystem paths.
import os, io, zipfile, warnings, random, json, time   # Operating-system utilities, ZIP I/O, warnings, RNG, JSON, and timing.
import numpy as np                  # Numerical computing.
import pandas as pd                 # Tabular data processing.
import matplotlib.pyplot as plt     # Plotting.

from sklearn.linear_model import Ridge                 # Ridge regression.
from sklearn.ensemble import RandomForestRegressor     # Random forest regression.
from sklearn.metrics import mean_absolute_error, mean_squared_error  # Regression evaluation metrics.
from xgboost import XGBRegressor    # XGBoost regression.
from statsmodels.tsa.arima.model import ARIMA          # ARIMA time-series model.
import copy                         # Deep copy for best model weights.
import torch                        # PyTorch deep-learning framework.
from torch import nn                # Neural-network layers.
from torch.utils.data import DataLoader, TensorDataset # Tensor datasets and data loaders.

SEED = 42                           # Global random seed for reproducibility.
random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)  # Seed Python, NumPy, and PyTorch.
if torch.cuda.is_available(): torch.cuda.manual_seed_all(SEED)    # Seed CUDA when available.
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # Choose CUDA if available, otherwise CPU.
DATA_DIR = Path('.')  # Set the directory containing the input ZIP files.
# Create a unique numbered output subdirectory for each run.
EXPERIMENT = 'AllData_Frozen_Hybrids_WalkForward_4Targets'
OUTPUT_ROOT = DATA_DIR / 'oil_outputs' / EXPERIMENT
OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
previous_runs = [int(p.name) for p in OUTPUT_ROOT.iterdir() if p.is_dir() and p.name.isdigit()]
RUN_ID = max(previous_runs, default=0) + 1
OUTPUT_DIR = OUTPUT_ROOT / str(RUN_ID)
OUTPUT_DIR.mkdir(parents=True, exist_ok=False)
HORIZONS = [1, 5, 20, 60]          # Forecast horizons in WTI trading days.
ABLATION_GROUPS = ['WTI', 'Brent', 'Energy', 'Macro']
TARGET = 'CL1_PX_LAST'             # WTI front-month continuous futures settlement/last price.
TRAIN_END = pd.Timestamp('2020-12-31')  # Training cutoff; updated for each fold.
VAL_END = pd.Timestamp('2021-12-31')  # Validation cutoff; updated for each fold.
# Disable fast mode for full training.
FAST_MODE = False                   # Fast debugging mode with reduced training budgets.
DL_EPOCHS = 20 if FAST_MODE else 100    # Maximum neural-network training epochs.
ARIMA_MAX_ORIGINS = 60 if FAST_MODE else None   # Limit ARIMA forecast origins in fast mode.
print('PyTorch:', torch.__version__, '| device:', DEVICE, '| output:', OUTPUT_DIR)  # Print environment and output paths.
print("Input directory:", DATA_DIR.resolve())
print("ZIP inventory:", [(p.name,p.exists()) for p in DATA_DIR.glob("*.zip")])
print("Output run:",OUTPUT_DIR.resolve())

# ===== USER CONFIGURATION =====
TARGET_MODE = 'LOG_RETURN'  # PRICE_LEVEL / SIMPLE_RETURN / LOG_RETURN / NORMALIZED_CHANGE
FOLD_CONFIG = [
    ('2020-12-31','2021-12-31','2022-12-31'),
    ('2021-12-31','2022-12-31','2023-12-31'),
    ('2022-12-31','2023-12-31','2024-12-31'),
    ('2023-12-31','2024-12-31','2025-12-31'),
    ('2025-09-30','2026-09-30','2026-10-23')
]
# Optional fixed-length training period; None means expanding window.
TRAIN_WINDOW_YEARS = None
RUN_ARIMA = True  # ARIMA refits per origin and can be slow
RUN_DEEP_LEARNING = True
RUN_LSTM_XGBOOST = True
RUN_EXTRA_HYBRIDS = True
assert TARGET_MODE in {'PRICE_LEVEL','SIMPLE_RETURN','LOG_RETURN','NORMALIZED_CHANGE'}
print('Target mode:',TARGET_MODE,'| planned folds:',len(FOLD_CONFIG))



# ============================================================================
# Data overview and missingness
# ============================================================================


# ========================================================================
# Part 2: Load and inspect market data
# ========================================================================
# ============================================================
# Read CSV files from ZIP archives and inspect column names.
# ============================================================

ZIP_FILES = {                       # Input ZIP filenames for the source datasets.
    'wti': '01 WTI&Brent.zip',      # WTI and Brent source data.
    'energy': '02 Energy_Commodities.zip',  # Energy commodity data.
    'macro': '03 Macro.zip',        # Macro-financial data.
}

def read_csv_from_zip(zip_path, csv_basename):
    """Read a CSV by filename from a ZIP archive; return a numeric, date-indexed DataFrame."""
    if not zip_path.exists():       # Raise an error when the ZIP archive is missing.
        raise FileNotFoundError(f'Missing: {zip_path}. Update DATA_DIR.')
    with zipfile.ZipFile(zip_path) as z:    # Open the ZIP archive.
        matches = [x for x in z.namelist() if Path(x).name == csv_basename]  # Find the specified CSV in the archive.
        if len(matches) != 1:       # Require exactly one matching file.
            raise ValueError(f'Expected one {csv_basename} in {zip_path}; got {matches}')
        df = pd.read_csv(io.BytesIO(z.read(matches[0])), low_memory=False)  # Read CSV content directly from ZIP bytes.
    df['Date'] = pd.to_datetime(df['Date'], errors='coerce')   # Parse dates; invalid dates become NaT.
    df = df.dropna(subset=['Date']).sort_values('Date').drop_duplicates('Date', keep='last')  # Drop missing dates, sort, and deduplicate.
    for col in df.columns.drop('Date'):   # Iterate over all non-date columns.
        df[col] = pd.to_numeric(df[col], errors='coerce')   # Convert values to numeric, coercing errors to NaN.
    return df.set_index('Date')     # Use Date as the DataFrame index.

wti = read_csv_from_zip(DATA_DIR / ZIP_FILES['wti'], 'WTI_clean_daily.csv')    # Load daily WTI data.
brent = read_csv_from_zip(DATA_DIR / ZIP_FILES['wti'], 'Brent_clean_daily.csv')  # Load daily Brent data.
energy = read_csv_from_zip(DATA_DIR / ZIP_FILES['energy'], '02_Energy_Commodities_Aligned.csv')  # Load energy commodity data.
macro = read_csv_from_zip(DATA_DIR / ZIP_FILES['macro'], 'Bloomberg_8_Macro_PX_LAST_Aligned.csv')  # Load macro-financial data.
for name, df in [('WTI',wti),('Brent',brent),('Energy',energy),('Macro',macro)]:  # Inspect all four source tables.
    print(name, 'rows:', len(df), 'cols:', len(df.columns), 'from', df.index.min().date(), 'to', df.index.max().date())  # Print table dimensions and date coverage.
    print('  ', ', '.join(df.columns[:10]))   # Print the first ten column names.
assert TARGET in wti.columns        # Verify the WTI target column exists.
# Data overview: every source column, missing counts, percentages, first/last valid dates.
source_tables={'WTI':wti,'Brent':brent,'Energy':energy,'Macro':macro}
overview=[]
for source,tab in source_tables.items():
    for col in tab.columns:
        valid=tab[col].dropna()
        overview.append({'source':source,'column':col,'rows':len(tab),'first_date':tab.index.min(),
                         'last_date':tab.index.max(),'missing_n':int(tab[col].isna().sum()),
                         'missing_pct':round(100*tab[col].isna().mean(),3),
                         'first_valid':valid.index.min() if len(valid) else pd.NaT,
                         'last_valid':valid.index.max() if len(valid) else pd.NaT})
source_overview=pd.DataFrame(overview)
display(source_overview)
source_overview.to_csv(OUTPUT_DIR/'source_missing_overview.csv',index=False)



# ============================================================================
# Data preprocessing
# ============================================================================


# ============================================================================
# Same-date alignment and missing-value audit
# ============================================================================


# ========================================================================
# Part 3: Align data and handle missing values
# ========================================================================
# Same-date left join on original WTI trading calendar (NO lag / asof).
START_DATE = "2015-02-06"
TARGET = "CL1_PX_LAST"
HORIZONS = [1, 5]

EXCLUDE_DATES = pd.to_datetime([
    "2020-04-20",
    "2020-04-21"
])

OUTPUT_DIR = Path(OUTPUT_DIR)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# ------------------------------------------------------------
# 1. Same-date alignment on original WTI calendar
# ------------------------------------------------------------

raw_unfilled = (
    wti.join(
        [
            brent.add_prefix("B_"),
            energy.add_prefix("E_"),
            macro.add_prefix("M_")
        ],
        how="left"
    )
    .sort_index()
)

raw_unfilled = raw_unfilled.loc[
    raw_unfilled.index >= pd.Timestamp(START_DATE)
].copy()

assert raw_unfilled.index.is_unique
assert raw_unfilled.index.is_monotonic_increasing
assert TARGET in raw_unfilled.columns

# ------------------------------------------------------------
# 2. Preserve original WTI prices and trading calendar
#    BEFORE excluding any dates
# ------------------------------------------------------------

original_wti_calendar = raw_unfilled.index.copy()
original_wti_target = raw_unfilled[TARGET].copy()

# ------------------------------------------------------------
# 3. Identify excluded dates and missing target prices
# ------------------------------------------------------------

event_mask = raw_unfilled.index.isin(EXCLUDE_DATES)
missing_target_mask = raw_unfilled[TARGET].isna()

remove_mask = event_mask | missing_target_mask

removed_audit = pd.DataFrame({
    "Date": raw_unfilled.index[remove_mask],
    "Reason": [
        ", ".join(
            reason for reason, condition in [
                ("Excluded negative-oil event", event),
                ("Missing WTI target", missing)
            ]
            if condition
        )
        for event, missing in zip(
            event_mask[remove_mask],
            missing_target_mask[remove_mask]
        )
    ]
})

# ------------------------------------------------------------
# 4. Keep valid prediction-origin dates
# ------------------------------------------------------------

raw_unfilled = raw_unfilled.loc[~remove_mask].copy()

# ------------------------------------------------------------
# 5. Preserve observed target prices
# ------------------------------------------------------------

original_target = raw_unfilled[TARGET].copy()

# ------------------------------------------------------------
# 6. Audit missing values BEFORE filling
# ------------------------------------------------------------

missing_original = raw_unfilled.isna()

# Missing indicators for input variables
missing_flags = (
    missing_original
    .drop(columns=[TARGET], errors="ignore")
    .astype("int8")
    .add_suffix("_missing")
)

# ------------------------------------------------------------
# 7. Unified Forward Fill for predictor columns
# ------------------------------------------------------------

raw = raw_unfilled.copy()

feature_cols = [
    c for c in raw.columns
    if c != TARGET
]

raw[feature_cols] = raw[feature_cols].ffill()

# Never impute the WTI target
raw[TARGET] = original_target

# ------------------------------------------------------------
# 8. Construct future targets on ORIGINAL WTI calendar
#    Do not shift the already-filtered raw DataFrame.
# ------------------------------------------------------------

future_targets = pd.DataFrame(index=original_wti_calendar)

for h in HORIZONS:

    future_price = original_wti_target.shift(-h)

    # Original WTI trading-day realization date
    realized_date = pd.Series(
        original_wti_calendar,
        index=original_wti_calendar
    ).shift(-h)

    current_price = original_wti_target

    # Preserve original normalized price-change definition
    denominator = current_price.abs().where(
        current_price.abs() > 1e-6
    )

    y = (future_price - current_price) / denominator

    # Exclude labels realized on the two event dates
    valid = (
        current_price.notna()
        & future_price.notna()
        & (~realized_date.isin(EXCLUDE_DATES))
    )

    future_targets[f"y_{h}"] = y.where(valid)
    future_targets[f"future_price_{h}"] = future_price.where(valid)
    future_targets[f"realized_date_{h}"] = realized_date

# Match labels to retained prediction-origin dates
future_targets = future_targets.reindex(raw.index)

# ------------------------------------------------------------
# 9. Missing-value audit
# ------------------------------------------------------------

fill_audit = pd.DataFrame({
    "Missing_Before": missing_original.sum(),
    "Missing_After": raw.isna().sum()
})

fill_audit["Filled_Count"] = (
    fill_audit["Missing_Before"]
    - fill_audit["Missing_After"]
)

fill_audit["Missing_Percent_After"] = (
    fill_audit["Missing_After"] / len(raw) * 100
)

fill_audit = fill_audit.sort_values(
    "Missing_Before",
    ascending=False
)

# ------------------------------------------------------------
# 10. Save outputs
# ------------------------------------------------------------

raw.to_csv(
    OUTPUT_DIR / "aligned_raw_cleaned.csv",
    index_label="Date"
)

future_targets.to_csv(
    OUTPUT_DIR / "future_targets.csv",
    index_label="Date"
)

fill_audit.to_csv(
    OUTPUT_DIR / "ffill_audit.csv",
    index_label="Column"
)

removed_audit.to_csv(
    OUTPUT_DIR / "removed_dates.csv",
    index=False
)

missing_flags.to_csv(
    OUTPUT_DIR / "missing_flags.csv",
    index_label="Date"
)

# ------------------------------------------------------------
# 11. Final checks
# ------------------------------------------------------------

assert raw[TARGET].notna().all()
assert not raw.index.isin(EXCLUDE_DATES).any()

print("=" * 65)
print("DATA PREPROCESSING SUMMARY")
print("=" * 65)

print("Date range:",
      raw.index.min().date(),
      "to",
      raw.index.max().date())

print("Rows retained:", len(raw))
print("Rows removed:", len(removed_audit))
print("Columns:", raw.shape[1])

print("Missing before FFill:",
      int(missing_original.sum().sum()))

print("Missing after FFill:",
      int(raw.isna().sum().sum()))

print("Filled cells:",
      int(fill_audit["Filled_Count"].sum()))

print("\nValid targets by horizon:")
for h in HORIZONS:
    print(f"h={h:2d}:",
          int(future_targets[f"y_{h}"].notna().sum()))

print("\nRemoved dates:")
display(removed_audit)

print("\nMissing-value audit:")
display(fill_audit.head(20))

print("\nFuture target sample:")
display(future_targets.head())



# ============================================================================
# Financial feature engineering and rolling standardization
# ============================================================================


# ========================================================================
# Part 4: Engineer and standardize financial features
# ========================================================================
# Causal financial features, shared by all model families.
# Construct from same-day aligned panel. No model-specific imputation.
def price_delta(s,lag): return s-s.shift(lag)
def safe_relative_change(s,lag):
    old=s.shift(lag)
    return (s-old)/old.abs().where(old.abs()>1e-6)
features=pd.DataFrame(index=raw.index)
feature_groups={'WTI':[],'Brent':[],'Energy':[],'Macro':[]}
def add(group,key,series):
    features[key]=series.replace([np.inf,-np.inf],np.nan)
    feature_groups[group].append(key)
# Use observed or conservatively filled prices; do not use supplied log returns.
price_map={
 'WTI': [('wti1','CL1_PX_LAST'),('wti2','CL2_PX_LAST'),('wti3','CL3_PX_LAST')],
 'Brent':[('brent1','B_CO1_PX_LAST'),('brent2','B_CO2_PX_LAST'),('brent3','B_CO3_PX_LAST')],
 'Energy': [('gold','E_GC1_PX_LAST'),('copper','E_HG1_PX_LAST'),('heating','E_HO1_PX_LAST'),('gas','E_NG1_PX_LAST'),('gasoline','E_XB1_PX_LAST')],
 'Macro': [('bcom','M_BCOM'),('dxy','M_DXY'),('eurusd','M_EURUSD'),('spx','M_SPX'),('usdcny','M_USDCNY')]
}
for group,pairs in price_map.items():
    for prefix,col in pairs:
        if col not in raw:continue
        s=raw[col]
        add(group,prefix+'_level',s)
        for lag in [1,5,20]:add(group,prefix+f'_delta{lag}',price_delta(s,lag))
# Preserve price level and economically meaningful spreads.
for key,a,b,group in [('wti_spread12','CL1_PX_LAST','CL2_PX_LAST','WTI'),
                      ('wti_spread23','CL2_PX_LAST','CL3_PX_LAST','WTI'),
                      ('brent_spread12','B_CO1_PX_LAST','B_CO2_PX_LAST','Brent'),
                      ('brent_wti_spread','B_CO1_PX_LAST','CL1_PX_LAST','Brent')]:
    if a in raw and b in raw:add(group,key,raw[a]-raw[b])
# WTI volatility uses changes, not log returns; negative prices remain valid.
for win in [5,20,60]:
    add('WTI',f'wti_vol{win}',raw[TARGET].diff().rolling(win,min_periods=win).std(ddof=0))
for group,tab in [('WTI',wti),('Brent',brent),('Energy',energy),('Macro',macro)]:
    prefix={'WTI':'','Brent':'B_','Energy':'E_','Macro':'M_'}[group]
    for original in tab.columns:
        col=prefix+original
        if col not in raw or col==TARGET or ('Return' in col or 'return' in col):continue
        if ('VOLUME' in col or 'OPEN_INT' in col or 'PX_VOLUME' in col):
            add(group,col+'_level',raw[col])
            add(group,col+'_delta5',raw[col].diff(5))
for col in ['M_VIX','M_USGG2YR','M_USGG10YR']:
    if col in raw:
        add('Macro',col+'_level',raw[col]);add('Macro',col+'_delta5',raw[col].diff(5))
if {'M_USGG2YR','M_USGG10YR'} <= set(raw.columns):
    add('Macro','yield_curve_10y2y',raw['M_USGG10YR']-raw['M_USGG2YR'])
# Missing flags are attached to their source group; target-missing flag excluded.
for group,tab in [('WTI',wti),('Brent',brent),('Energy',energy),('Macro',macro)]:
    prefix={'WTI':'','Brent':'B_','Energy':'E_','Macro':'M_'}[group]
    for col in tab.columns:
        k=prefix+col+'_missing'
        if k in missing_flags and ('Return' not in col and 'return' not in col):
            add(group,k,missing_flags[k])
# Rolling 60: the first 60 WTI dates are warm-up, first valid normalized day is day 61.
# Statistics use PREVIOUS 60 WTI rows (not current date, not future dates).
ROLLING_WINDOW=60
binary_cols=[c for c in features if c.endswith('_missing')]
continuous_cols=[c for c in features if c not in binary_cols]
mu=features[continuous_cols].shift(1).rolling(ROLLING_WINDOW,min_periods=ROLLING_WINDOW).mean()
sigma=features[continuous_cols].shift(1).rolling(ROLLING_WINDOW,min_periods=ROLLING_WINDOW).std(ddof=0)
scaled=(features[continuous_cols]-mu)/sigma.mask(sigma.abs()<1e-8)
# Pre-impute sparse feature observations using train-only median BEFORE causal scaling;
# instead use causal forward fill for engineered feature values with a short cap, then
# train-only median for remaining sparse gaps in the unscaled panel.
# The causal rolling scaler itself uses only past observed/filled values.
scaled=scaled.replace([np.inf,-np.inf],np.nan)
features_scaled=pd.concat([scaled,features[binary_cols]],axis=1).reindex(columns=features.columns)
mask=(features_scaled.index<=TRAIN_END)&(np.arange(len(features_scaled))>=ROLLING_WINDOW)
usable=features_scaled.loc[mask].median().fillna(0)
# Drop unusable features with no finite train-period standardized observations.
unusable=[c for c in continuous_cols if features_scaled.loc[mask,c].notna().sum()==0]
features_scaled=features_scaled.drop(columns=unusable)
for group in feature_groups:feature_groups[group]=[c for c in feature_groups[group] if c not in unusable]
features_scaled=features_scaled.fillna(usable.reindex(features_scaled.columns).fillna(0)).astype('float32')
# Exclude warm-up dates as prediction origins; retain history for sequences after warm-up.
features_scaled.iloc[:ROLLING_WINDOW]=np.nan
print('Engineered features:',len(features.columns),'| usable:',features_scaled.shape[1],
      '| dropped unusable:',len(unusable),'| warm-up:',ROLLING_WINDOW)
features_scaled.to_csv(OUTPUT_DIR/'standardized_features.csv',index_label='Date')



# ============================================================================
# Target construction and chronological splits
# ============================================================================


# ========================================================================
# Part 5: Construct forecasting targets and chronological splits
# ========================================================================
# Targets are calculated from the original, uncompressed WTI calendar.
# For SIMPLE_RETURN, this is the h-step cumulative SIMPLE return, not a single future day's return.
# LOG_RETURN is only defined when both endpoint prices are positive.
raw_target = original_target.copy().sort_index()
EXCLUDED_ORIGINS = pd.DatetimeIndex([])  # optional excluded prediction-origin dates

def make_dataset(h):
    future = raw_target.shift(-h)
    current = raw_target
    realized = pd.Series(raw_target.index, index=raw_target.index).shift(-h)
    if TARGET_MODE == 'PRICE_LEVEL':
        y = future.copy()
    elif TARGET_MODE == 'PRICE_CHANGE':
        y = future - current
    elif TARGET_MODE == 'SIMPLE_RETURN':
        y = (future-current) / current.where(current.abs()>1e-6)
    elif TARGET_MODE == 'LOG_RETURN':
        positive = (current>0) & (future>0)
        y = np.log(future.where(positive)/current.where(positive))
    elif TARGET_MODE == 'NORMALIZED_CHANGE':
        y = (future-current)/current.abs().where(current.abs()>1e-6)
    else:
        raise ValueError(TARGET_MODE)
    frame = features_scaled.copy()
    frame['y'] = y
    frame['current_price'] = current
    frame['future_price'] = future
    frame['realized_date'] = realized
    frame = frame.iloc[ROLLING_WINDOW:]
    frame = frame.dropna(subset=['y','current_price','future_price','realized_date'])
    frame = frame.loc[~frame.index.isin(EXCLUDED_ORIGINS)]
    if TARGET_MODE in ('NORMALIZED_CHANGE','SIMPLE_RETURN'):
        frame = frame.loc[frame.current_price.abs()>=1.0]
    # Split by both origin and realization date to avoid label leakage across boundaries.
    tr = frame[(frame.index<=TRAIN_END)&(frame.realized_date<=TRAIN_END)]
    if FOLD_TRAIN_START is not None:
        tr = tr[tr.index>=FOLD_TRAIN_START]
    va = frame[(frame.index>TRAIN_END)&(frame.index<=VAL_END)&(frame.realized_date<=VAL_END)]
    te = frame[(frame.index>VAL_END)&(frame.index<=TEST_END)&(frame.realized_date<=TEST_END)]
    return tr,va,te

FOLD_TRAIN_START = None
TEST_END = pd.Timestamp('2022-12-31')
for h in HORIZONS:
    tr,va,te=make_dataset(h)
    print(f'h={h}: train={len(tr)}, val={len(va)}, test={len(te)}')



# ============================================================================
# Shared feature panel, target inversion, and evaluation
# ============================================================================


# ========================================================================
# Part 6: Prepare shared model inputs and evaluation functions
# ========================================================================
# All models consume the SAME preprocessed feature matrix.
ACTIVE_GROUPS=ABLATION_GROUPS
FEATURE_COLUMNS=[c for g in ACTIVE_GROUPS for c in feature_groups[g]]
assert FEATURE_COLUMNS and len(FEATURE_COLUMNS)==len(set(FEATURE_COLUMNS))
features=features_scaled # compatibility alias: immutable prepared panel
print('Feature groups:',{g:len(feature_groups[g]) for g in feature_groups})
print('Active:',ACTIVE_GROUPS,'selected columns:',len(FEATURE_COLUMNS))

def prepare_tabular(train,val,test):
    # No fit/transform or imputation inside a model. Already prepared upstream.
    matrices=tuple(d[FEATURE_COLUMNS].to_numpy(dtype=np.float32) for d in (train,val,test))
    for arr in matrices:assert np.isfinite(arr).all(), 'Invalid preprocessed model input'
    return matrices,matrices,(None,None)

def inverse_target(pred_y,current):
    pred_y=np.asarray(pred_y,dtype=float).reshape(-1)
    current=np.asarray(current,dtype=float).reshape(-1)
    if TARGET_MODE=='PRICE_LEVEL': return pred_y
    if TARGET_MODE=='PRICE_CHANGE': return current+pred_y
    if TARGET_MODE=='SIMPLE_RETURN': return current*(1.0+pred_y)
    if TARGET_MODE=='LOG_RETURN': return current*np.exp(np.clip(pred_y,-30,30))
    if TARGET_MODE=='NORMALIZED_CHANGE': return current+np.abs(current)*pred_y
    raise ValueError(TARGET_MODE)

def target_from_price(future,current):
    future=np.asarray(future,dtype=float)
    current=np.asarray(current,dtype=float)
    if TARGET_MODE=='PRICE_LEVEL': return future
    if TARGET_MODE=='PRICE_CHANGE': return future-current
    if TARGET_MODE=='SIMPLE_RETURN': return (future-current)/current
    if TARGET_MODE=='LOG_RETURN': return np.log(future/current)
    if TARGET_MODE=='NORMALIZED_CHANGE': return (future-current)/np.abs(current)
    raise ValueError(TARGET_MODE)

def evaluate(name,h,split,df,pred_y):
    pred_y=np.asarray(pred_y,dtype=float).reshape(-1)
    actual=df.future_price.to_numpy(dtype=float)
    current=df.current_price.to_numpy(dtype=float)
    pred_price=inverse_target(pred_y,current)
    if not np.isfinite(pred_price).all():
        raise ValueError(f'Nonfinite predictions from {name} h={h}')
    direction=np.mean(np.sign(actual-current)==np.sign(pred_price-current))
    result={'model':name,'horizon':h,'split':split,'n':len(df),
            'MAE':float(mean_absolute_error(actual,pred_price)),
            'MSE':float(mean_squared_error(actual,pred_price)),
            'RMSE':float(np.sqrt(mean_squared_error(actual,pred_price))),
            'Direction_Accuracy':float(direction)}
    pred_df=pd.DataFrame({'Date':df.index,'realized_date':df.realized_date.values,'model':name,
                          'horizon':h,'split':split,'current_price':current,
                          'actual_price':actual,'predicted_price':pred_price,
                          'actual_return':df.y.values,'predicted_return':pred_y})
    return result,pred_df

all_metrics=[];all_predictions=[]
def record(name,h,split,df,yhat):
    metric,pred=evaluate(name,h,split,df,yhat)
    metric['fold']=CURRENT_FOLD
    pred['fold']=CURRENT_FOLD
    metric['target_mode']=TARGET_MODE
    pred['target_mode']=TARGET_MODE
    all_metrics.append(metric);all_predictions.append(pred)

# Price-MSE option: only changes supervised training losses, not Y or evaluation.
LOSS_MODE = 'PRICE_MSE'  # 'PRICE_MSE' or 'TARGET_MSE'

def torch_price_from_target(pred, current):
    if TARGET_MODE == 'PRICE_LEVEL': return pred
    if TARGET_MODE == 'PRICE_CHANGE': return current + pred
    if TARGET_MODE == 'SIMPLE_RETURN': return current * (1.0 + pred)
    if TARGET_MODE == 'NORMALIZED_CHANGE': return current + current.abs() * pred
    if TARGET_MODE == 'LOG_RETURN': return current * torch.exp(torch.clamp(pred, -30., 30.))
    raise ValueError(TARGET_MODE)

def supervised_loss(pred, y, current, future):
    if LOSS_MODE == 'TARGET_MSE': return nn.functional.mse_loss(pred.reshape(-1), y.reshape(-1))
    return nn.functional.mse_loss(torch_price_from_target(pred.reshape(-1), current.reshape(-1)), future.reshape(-1))

def numpy_validation_loss(pred, df):
    if LOSS_MODE == 'TARGET_MSE': return float(np.mean((np.asarray(pred)-df.y.to_numpy())**2))
    return float(np.mean((inverse_target(np.asarray(pred),df.current_price.to_numpy())-df.future_price.to_numpy())**2))




# ============================================================================
# Model definitions and fold-level training
# ============================================================================


# ============================================================================
# Random walk and historical-mean baselines
# ============================================================================


# ========================================================================
# Part 7: Statistical benchmark forecasts
# ========================================================================
def run_baselines():
    # ============================================================
    # Baseline models.
    # ============================================================

    for h in HORIZONS:                       # Forecast horizons in WTI trading days.
        train,val,test = make_dataset(h)     # Construct data for this horizon.
        for split,df in [('validation',val),('test',test)]:   # Evaluate validation and test partitions.
            record('RandomWalk',h,split,df,target_from_price(df.current_price.to_numpy(),df.current_price.to_numpy()))   # No-change forecast: future price equals current price.
            record('HistoricalMean',h,split,df,np.full(len(df),train.y.mean()))  # Predict using the training-set mean target.
    print(pd.DataFrame(all_metrics).head(8).round(4).to_string(index=False))   # Display the first eight metric records.



# ============================================================================
# Ridge, random forest, and XGBoost
# ============================================================================


# ========================================================================
# Part 8: Traditional machine learning models
# ========================================================================
def run_tabular_models():
    global selected_models, ml_selection
    # ============================================================
    # Machine-learning models.
    # ============================================================

    ML_SPECS = {   # Candidate hyperparameter configurations.
     'Ridge': [('alpha='+str(a),Ridge(alpha=a)) for a in [1,10,100]],   # Candidate ridge regularization strengths.
     'RandomForest': [(f'leaf={leaf}',RandomForestRegressor(n_estimators=120 if FAST_MODE else 300,   # Candidate minimum leaf sizes.
                          min_samples_leaf=leaf,max_features=0.8,n_jobs=-1,random_state=SEED)) for leaf in [3,10]],
     'XGBoost': [(f'depth={depth}',XGBRegressor(n_estimators=200 if FAST_MODE else 500,max_depth=depth,   # Candidate tree depths.
                    learning_rate=0.04,subsample=0.85,colsample_bytree=0.85,reg_lambda=5,
                    objective='reg:squarederror',n_jobs=4,random_state=SEED)) for depth in [2,4]],
    }
    selected_models={}; ml_selection=[]   # Store fitted models and selection records.
    for h in HORIZONS:                    # Forecast horizons in WTI trading days.
        tr,va,te = make_dataset(h)        # Implementation note for the adjacent operation.
        (xtr,xva,xte),_,prep=prepare_tabular(tr,va,te)   # Implementation note for the adjacent operation.
        for name,candidates in ML_SPECS.items():   # Iterate over models.
            best=None                      # Track the best validation candidate.
            for label,model in candidates: # Evaluate each hyperparameter candidate.
                model.fit(xtr,tr.y.to_numpy())        # Fit on training data only.
                yhat=model.predict(xva)               # Predict on validation data.
                metric,_=evaluate(name,h,'validation',va,yhat)   # Evaluate validation metrics.
                if best is None or metric['RMSE']<best[0]: best=(metric['RMSE'],label,model,yhat)  # Keep the candidate with the lowest validation RMSE.
            _,label,model,val_pred=best    # Unpack the best candidate.
            record(name,h,'validation',va,val_pred)         # Record validation predictions.
            record(name,h,'test',te,model.predict(xte))     # Evaluate the selected model on the test set.
            selected_models[(name,h)] = (model,prep)        # Store the selected fitted model.
            ml_selection.append({'horizon':h,'model':name,'selected':label,'val_RMSE':best[0]})  # Record selected hyperparameters.
    print(pd.DataFrame(ml_selection).round(4).to_string(index=False))   # Print model selections and validation scores.



# ============================================================================
# ARIMA
# ============================================================================


# ========================================================================
# Part 9: ARIMA forecasting
# ========================================================================
# ============================================================
# expanding-origin forecasting benchmark.
# ============================================================

def arima_origin_predictions(df,h,order=(1,1,0),max_origins=None):
    """Refit ARIMA using prices available at each origin and forecast h trading days ahead."""
    selected = df.tail(max_origins) if max_origins is not None else df   # Restrict forecast origins when a cap is configured.
    out=[]                             # Collect predictions for each origin.
    series = raw_target.astype(float) # Historical WTI front-month price series.
    for origin in selected.index:      # Iterate over forecast origin dates.
        history = series.loc[:origin].dropna()   # Use observations available through the forecast origin.
        try:
            with warnings.catch_warnings():       # Suppress statsmodels convergence warnings.
                warnings.simplefilter('ignore')
                fit=ARIMA(history.to_numpy(),order=order).fit()   # Fit ARIMA(1,1,0).
                future_price=float(fit.forecast(steps=h)[-1])     # Forecast h steps and select the terminal forecast.
        except Exception:               # Fall back if fitting fails.
            future_price=float(history.iloc[-1])   # Use a no-change price forecast as fallback.
        current=float(selected.loc[origin,'current_price'])   # Current price at this forecast origin.
        out.append(float(target_from_price([future_price],[current])[0]))       # Convert predicted price to the selected target scale.
    return selected,np.asarray(out)     # Return aligned observations and predictions.


def run_arima():
    # Skip costly ARIMA fits during exploratory runs.

    if RUN_ARIMA:
        for h in HORIZONS:                 # Forecast horizons in WTI trading days.
            tr,va,te=make_dataset(h)       # Implementation note for the adjacent operation.
            for split,df in [('validation',va),('test',te)]:   # Evaluate validation and test partitions.
                subset,pred=arima_origin_predictions(df,h,max_origins=ARIMA_MAX_ORIGINS)   # Refit and predict at each origin.
                record('ARIMA(1,1,0)',h,split,subset,pred)     # Store evaluation results.
            print('ARIMA complete:',h)     # Print progress.



# ============================================================================
# MLP, GRU, and LSTM
# ============================================================================


# ========================================================================
# Part 10: Neural network architectures and training
# ========================================================================
# ============================================================
# Construct sequences.
# ============================================================

LOOKBACK=60   # Historical lookback length in trading days.

def build_sequences(h):
    """Build aligned sequence/target arrays for training, validation, and testing."""
    train,val,test=make_dataset(h)      # Create chronological tabular partitions.
    # Unified standardized panel, no new preprocessing inside sequence models.
    Xall=features[FEATURE_COLUMNS].to_numpy(dtype=np.float32)
    position=pd.Series(np.arange(len(features)),index=features.index)  # Map dates to feature-row positions.
    def assemble(df):
        xx=[]; yy=[]; keep=[]          # Collect sequences, labels, and retained dates.
        for date,row in df.iterrows(): # Iterate over observations in this partition.
            i=int(position.loc[date])  # Find the feature-row position for this date.
            if i<ROLLING_WINDOW+LOOKBACK-1: continue  # Skip rows without sufficient lookback history.
            xx.append(Xall[i-LOOKBACK+1:i+1])   # Extract the historical feature sequence.
            yy.append(float(row['y']))          # Target for this observation.
            keep.append(date)                    # Retain the corresponding date.
        if not xx: raise ValueError('No sequences: reduce LOOKBACK')  # Fail if no valid sequences are available.
        return np.stack(xx),np.asarray(yy,dtype=np.float32),df.loc[keep]   # Return sequences, targets, and aligned rows.
    return assemble(train),assemble(val),assemble(test)   # Build training, validation, and test sequences.

class OilNet(nn.Module):
    """Neural architectures: flattened MLP, GRU, and LSTM."""
    def __init__(self, kind, input_shape):
        super().__init__()
        self.kind = kind                # Store the network architecture type.
        seq_len, n_features = input_shape   # Historical lookback length in trading days.
        if kind == 'MLP':               # Flatten the lookback sequence before dense layers.
            self.backbone = nn.Sequential(nn.Flatten(), nn.Linear(seq_len*n_features,64),
                                          nn.ReLU(), nn.Dropout(0.2), nn.Linear(64,32), nn.ReLU())
            self.head = nn.Linear(32,1) # Scalar regression output.
        elif kind in ('GRU','LSTM'):    # Recurrent GRU or LSTM architecture.
            recurrent = nn.GRU if kind == 'GRU' else nn.LSTM   # Choose recurrent cell type.
            self.backbone = recurrent(n_features,32,batch_first=True)   # Map input features to 32 hidden units.
            self.head = nn.Sequential(nn.Dropout(0.2),nn.Linear(32,16),nn.ReLU(),nn.Linear(16,1))  # Hidden representation and regression output.
        else:
            raise ValueError(kind)      # Reject unknown model type.

    def forward(self,x):
        if self.kind == 'MLP':          # Flatten MLP input.
            z = self.backbone(x)
        else:                           # Recurrent GRU or LSTM architecture.
            out, _ = self.backbone(x)
            z = out[:,-1,:]
        return self.head(z).squeeze(-1) # Return a flat vector of predictions.


def predict_nn(net,x,batch_size=512):
    """Run batched inference with a trained network and no gradients."""
    net.eval()                          # Switch to evaluation mode.
    outputs=[]
    with torch.no_grad():               # Disable gradients for inference.
        for (xb,) in DataLoader(TensorDataset(torch.from_numpy(x)),batch_size=batch_size):  # Iterate over batches.
            outputs.append(net(xb.to(DEVICE)).cpu().numpy())   # Run inference and move outputs to NumPy.
    return np.concatenate(outputs)      # Concatenate batches.


def fit_nn(kind,xtr,ytr,xva,yva,tr,va):
    """Train a neural network with validation early stopping and restore its best weights."""
    torch.manual_seed(SEED)             # Set deterministic initialization seed.
    net=OilNet(kind,xtr.shape[1:]).to(DEVICE)   # Instantiate model on the selected device.
    optimizer=torch.optim.Adam(net.parameters(),lr=1e-3)   # Adam optimizer.
    criterion=nn.MSELoss()              # Legacy target-space criterion; LOSS_MODE selects the active loss.
    train_loader=DataLoader(TensorDataset(torch.from_numpy(xtr),torch.from_numpy(ytr),torch.from_numpy(tr.current_price.to_numpy(dtype=np.float32)),torch.from_numpy(tr.future_price.to_numpy(dtype=np.float32))),
                            batch_size=64,shuffle=False)   # Training DataLoader; preserve temporal order.
    val_loader=DataLoader(TensorDataset(torch.from_numpy(xva),torch.from_numpy(yva),torch.from_numpy(va.current_price.to_numpy(dtype=np.float32)),torch.from_numpy(va.future_price.to_numpy(dtype=np.float32))),
                          batch_size=512,shuffle=False)    # Validation DataLoader.
    best_loss=float('inf'); best_state=None; bad_epochs=0  # Track best validation loss and early stopping.
    patience=4 if FAST_MODE else 8      # Early-stopping patience.
    for epoch in range(DL_EPOCHS):      # Train for each epoch.
        net.train()                     # Enable training mode.
        for xb,yb,cp,fp in train_loader:      # Iterate over training batches.
            xb,yb=xb.to(DEVICE),yb.to(DEVICE)   # Move tensors to the selected device.
            optimizer.zero_grad()       # Reset optimizer gradients.
            loss=supervised_loss(net(xb),yb,cp.to(DEVICE),fp.to(DEVICE))  # Forward pass and supervised loss.
            loss.backward()             # Backpropagate gradients.
            optimizer.step()            # Update model parameters.
        net.eval(); total=0.; count=0   # Enable evaluation mode.
        with torch.no_grad():
            for xb,yb,cp,fp in val_loader:    # Iterate over validation batches.
                xb,yb=xb.to(DEVICE),yb.to(DEVICE)
                total+=supervised_loss(net(xb),yb,cp.to(DEVICE),fp.to(DEVICE)).item()*len(yb)   # Accumulate sample-weighted loss.
                count+=len(yb)          # Accumulate sample count.
        val_loss=total/count            # Average validation loss.
        if val_loss < best_loss-1e-8:   # Check for validation improvement.
            best_loss=val_loss          # Update best validation loss.
            best_state=copy.deepcopy(net.state_dict())   # Save the current best state.
            bad_epochs=0                # Reset early-stopping counter.
        else:
            bad_epochs+=1               # Increment early-stopping counter.
            if bad_epochs>=patience: break   # Stop after patience epochs without improvement.
    net.load_state_dict(best_state)     # Restore the best model weights.
    return net


# ========================================================================
# Part 11: Train standalone neural forecasting models
# ========================================================================
def run_neural_models():
    global nn_models
    # ============================================================
    # Train MLP, GRU, and LSTM with early stopping.
    # ============================================================

       # Enable or disable neural-network training.
    nn_models = {}             # Store trained networks by model and horizon.
    if RUN_DEEP_LEARNING:
        for h in HORIZONS:                             # Forecast horizons in WTI trading days.
            (xtr,ytr,tr),(xva,yva,va),(xte,yte,te) = build_sequences(h)   # Construct sequences.
            for kind in ['MLP','GRU','LSTM']:          # Train each of the three neural architectures.
                net = fit_nn(kind,xtr,ytr,xva,yva,tr,va)     # Implementation note for the adjacent operation.
                record(kind,h,'validation',va,predict_nn(net,xva))   # Record validation predictions.
                record(kind,h,'test',te,predict_nn(net,xte))         # Record test predictions.
                nn_models[(kind,h)] = net              # Store trained network.
                print('Done:',kind,'h=',h)             # Print progress.



# ============================================================================
# Frozen LSTM encoder with XGBoost
# ============================================================================


# ========================================================================
# Part 12: Frozen encoder and hybrid model components
# ========================================================================
# ============================================================
# Hybrid LSTM encoder and XGBoost.
# ============================================================

# Hidden representation and regression output.
           # Enable hybrid-model training.
HYBRID_INCLUDE_EXPLICIT = False    # Optionally concatenate last-step explicit financial features.
HYBRID_HIDDEN = 32                # Hidden representation and regression output.

class HybridLSTMEncoder(nn.Module):
    """Supervised LSTM encoder maps a historical sequence to a latent vector and prediction head."""
    def __init__(self, input_dim, hidden_dim=32):
        super().__init__()
        self.lstm = nn.LSTM(input_size=input_dim, hidden_size=hidden_dim, batch_first=True)  # LSTM encoder layer.
        self.head = nn.Sequential(nn.Dropout(0.2), nn.Linear(hidden_dim, 16),
                                  nn.ReLU(), nn.Linear(16, 1))   # Prediction head.

    def encode(self, x):
        _, (h_n, _) = self.lstm(x)   # Hidden representation and regression output.
        return h_n[-1]               # Hidden representation and regression output.

    def forward(self, x):
        return self.head(self.encode(x)).squeeze(-1)   # Prediction head.


def fit_hybrid_encoder(xtr, ytr, xva, yva, tr, va):
    """Train the supervised LSTM encoder with validation early stopping."""
    torch.manual_seed(SEED)                                   # Set the random seed.
    model = HybridLSTMEncoder(xtr.shape[-1], HYBRID_HIDDEN).to(DEVICE)   # Instantiate the encoder.
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-4)  # Adam optimizer with weight decay.
    criterion = nn.MSELoss()                                  # Mean squared error criterion.
    train_loader = DataLoader(TensorDataset(torch.from_numpy(xtr),torch.from_numpy(ytr),torch.from_numpy(tr.current_price.to_numpy(dtype=np.float32)),torch.from_numpy(tr.future_price.to_numpy(dtype=np.float32))),
                              batch_size=64, shuffle=False)   # Training data loader.
    val_loader = DataLoader(TensorDataset(torch.from_numpy(xva),torch.from_numpy(yva),torch.from_numpy(va.current_price.to_numpy(dtype=np.float32)),torch.from_numpy(va.future_price.to_numpy(dtype=np.float32))),
                            batch_size=512, shuffle=False)    # Validation data loader.
    best_loss = float('inf')          # Track best validation loss and early stopping.
    best_state = None                 # Best model weights.
    bad_epochs = 0                    # Consecutive epochs without improvement.
    for epoch in range(DL_EPOCHS):    # Train for each epoch.
        model.train()                 # Enable training mode.
        for xb,yb,cp,fp in train_loader:   # Iterate over training batches.
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)   # Move tensors to the selected device.
            optimizer.zero_grad()     # Reset optimizer gradients.
            loss = supervised_loss(model(xb),yb,cp.to(DEVICE),fp.to(DEVICE))   # Forward pass and supervised loss.
            loss.backward()           # Backpropagate gradients.
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)  # Clip gradients to prevent explosion.
            optimizer.step()          # Update model parameters.
        model.eval()                  # Enable evaluation mode.
        total, count = 0., 0          # Accumulate sample-weighted loss.
        with torch.no_grad():
            for xb,yb,cp,fp in val_loader: # Iterate over validation batches.
                loss = supervised_loss(model(xb.to(DEVICE)),yb.to(DEVICE),cp.to(DEVICE),fp.to(DEVICE))
                total += float(loss.item()) * len(yb)   # Accumulate sample-weighted loss.
                count += len(yb)      # Accumulate sample count.
        val_loss = total / max(count, 1)   # Average validation loss.
        if val_loss < best_loss - 1e-8:    # Check for validation improvement.
            best_loss = val_loss      # Implementation note for the adjacent operation.
            best_state = copy.deepcopy(model.state_dict())   # Implementation note for the adjacent operation.
            bad_epochs = 0            # Implementation note for the adjacent operation.
        else:
            bad_epochs += 1           # Implementation note for the adjacent operation.
            if bad_epochs >= (4 if FAST_MODE else 8):   # Stop when early-stopping patience is reached.
                break
    if best_state is None:            # Raise an error if no valid validation state exists.
        raise RuntimeError('LSTM encoder failed to produce a valid validation loss')
    model.load_state_dict(best_state) # Restore the best model weights.
    for param in model.parameters():
        param.requires_grad_(False)  # Prediction head.
    model.eval()
    return model


def extract_hybrid_features(model, x, include_explicit=True):
    """Encode sequences into latent features; optionally append last-step explicit features."""
    model.eval()                      # Enable evaluation mode.
    pieces = []                       # Collect latent feature batches.
    with torch.no_grad():
        for (xb,) in DataLoader(TensorDataset(torch.from_numpy(x)), batch_size=512):  # Implementation note for the adjacent operation.
            pieces.append(model.encode(xb.to(DEVICE)).cpu().numpy())   # Encode and convert to NumPy.
    z = np.concatenate(pieces, axis=0)   # Concatenate batches.
    # Last time-step standardized explicit features.
    if include_explicit:
        z = np.concatenate([z, x[:, -1, :]], axis=1)   # Last time-step standardized explicit features.
    return z.astype(np.float32)       # Return float32 features.




# ========================================================================
# Part 13: Hybrid model training and predictions
# ========================================================================
def run_lstm_xgboost():
    global hybrid_encoders, hybrid_xgb_models, hybrid_selection
    hybrid_encoders = {}      # Store fitted models and selection records.
    hybrid_xgb_models = {}    # Store fitted models and selection records.
    hybrid_selection = []     # Store hybrid-model selection records.
    if RUN_LSTM_XGBOOST:
        for h in HORIZONS:                                       # Iterate over forecast horizons.
            (xtr,ytr,tr),(xva,yva,va),(xte,yte,te) = build_sequences(h)   # Construct sequences.
            encoder = fit_hybrid_encoder(xtr, ytr, xva, yva, tr, va)     # Pretrain the LSTM encoder.
            ztr = extract_hybrid_features(encoder, xtr, include_explicit=False)   # Training latent features.
            zva = extract_hybrid_features(encoder, xva, include_explicit=False)   # Validation latent features.
            zte = extract_hybrid_features(encoder, xte, include_explicit=False)   # Test latent features.
            candidates = [(2, 150)] if FAST_MODE else [(2, 300), (3, 300), (4, 500)]  # Candidate XGBoost depths and tree counts.
            best = None                    # Best validation candidate.
            for depth, ntrees in candidates:   # Evaluate each hyperparameter candidate.
                candidate = XGBRegressor(     # Instantiate XGBoost regressor.
                    n_estimators=ntrees, max_depth=depth, learning_rate=0.035,
                    subsample=0.85, colsample_bytree=0.85, reg_lambda=8.0,
                    objective='reg:squarederror', random_state=SEED, n_jobs=4)
                candidate.fit(ztr, ytr)      # Fit on training latent features.
                val_pred = candidate.predict(zva)   # Predict on validation latent features.
                val_metric, _ = evaluate('LSTM+XGBoost', h, 'validation', va, val_pred)   # Evaluate validation metrics.
                if best is None or val_metric['RMSE'] < best[0]:   # Keep the candidate with the lowest validation RMSE.
                    best = (val_metric['RMSE'], depth, ntrees, candidate, val_pred)
            val_rmse, depth, ntrees, model, val_pred = best   # Unpack the best candidate.
            record('LSTM+XGBoost', h, 'validation', va, val_pred)   # Record validation predictions.
            record('LSTM+XGBoost', h, 'test', te, model.predict(zte))   # Record test predictions.
            hybrid_encoders[h] = encoder    # Implementation note for the adjacent operation.
            hybrid_xgb_models[h] = model    # Implementation note for the adjacent operation.
            hybrid_selection.append({'horizon': h, 'depth': depth, 'trees': ntrees,   # Record selected hyperparameters.
                                     'latent_features': HYBRID_HIDDEN,
                                     'total_features': ztr.shape[1], 'val_RMSE': val_rmse})
            print(f'Hybrid complete: h={h}, train={len(tr)}, val={len(va)}, test={len(te)}, features={ztr.shape[1]}')  # Print progress.
        display(pd.DataFrame(hybrid_selection).round(4))   # Display hybrid model selection results.



# ============================================================================
# Frozen GRU and FactorVAE hybrid models
# ============================================================================


# ========================================================================
# Part 14: Aggregate model predictions
# ========================================================================
# ============================================================
# Frozen-encoder two-stage hybrids: GRU+MLP, GRU+XGBoost,
# unsupervised FactorVAE+MLP (latent-only downstream inputs).
# ============================================================

EXTRA_HIDDEN = 32
FACTOR_LATENT_DIM = 32
FACTOR_RECON_WEIGHT = 1.0
FACTOR_KL_WEIGHT = 0.01
FACTOR_TC_WEIGHT = 0.01

class GRUEncoder(nn.Module):
    def __init__(self, input_dim, hidden_dim=32):
        super().__init__()
        self.gru = nn.GRU(input_dim, hidden_dim, batch_first=True)
        self.head = nn.Sequential(nn.Dropout(0.2), nn.Linear(hidden_dim,16), nn.ReLU(), nn.Linear(16,1))
    def encode(self,x):
        _,hn=self.gru(x)
        return hn[-1]
    def forward(self,x):
        return self.head(self.encode(x)).squeeze(-1)

# Supervised GRU encoder: train only on TRAIN, early stop on VALIDATION.
def train_gru_encoder(xtr,ytr,xva,yva,tr,va):
    torch.manual_seed(SEED)
    net=GRUEncoder(xtr.shape[-1],EXTRA_HIDDEN).to(DEVICE)
    opt=torch.optim.Adam(net.parameters(),lr=1e-3,weight_decay=1e-4)
    best=float('inf'); best_state=None; bad=0
    train_loader=DataLoader(TensorDataset(torch.from_numpy(xtr),torch.from_numpy(ytr),torch.from_numpy(tr.current_price.to_numpy(dtype=np.float32)),torch.from_numpy(tr.future_price.to_numpy(dtype=np.float32))),batch_size=64,shuffle=False)
    for ep in range(DL_EPOCHS):
        net.train()
        for xb,yb,cp,fp in train_loader:
            xb,yb=xb.to(DEVICE),yb.to(DEVICE)
            opt.zero_grad(); loss=supervised_loss(net(xb),yb,cp.to(DEVICE),fp.to(DEVICE))
            loss.backward(); nn.utils.clip_grad_norm_(net.parameters(),1.0); opt.step()
        pred=run_gru_encoder_prediction(net,xva)
        score=numpy_validation_loss(pred,va)
        if score<best-1e-8:
            best=score;best_state=copy.deepcopy(net.state_dict());bad=0
        else:
            bad+=1
            if bad >= (4 if FAST_MODE else 8): break
    net.load_state_dict(best_state)
    for p in net.parameters(): p.requires_grad_(False)
    net.eval()
    return net

def run_gru_encoder_prediction(net,x):
    net.eval();out=[]
    with torch.no_grad():
        for (xb,) in DataLoader(TensorDataset(torch.from_numpy(x)),batch_size=512):
            out.append(net(xb.to(DEVICE)).cpu().numpy())
    return np.concatenate(out)

def extract_gru(net,x):
    net.eval(); out=[]
    with torch.no_grad():
        for (xb,) in DataLoader(TensorDataset(torch.from_numpy(x)),batch_size=512):
            out.append(net.encode(xb.to(DEVICE)).cpu().numpy())
    z=np.concatenate(out).astype(np.float32)
    return z  # ONLY 32 latent factors; no explicit feature concatenation

class GRUSecondStageMLP(nn.Module):
    def __init__(self,n_features):
        super().__init__()
        self.net=nn.Sequential(nn.Linear(n_features,64),nn.ReLU(),nn.Dropout(0.2),
                               nn.Linear(64,32),nn.ReLU(),nn.Linear(32,1))
    def forward(self,x):return self.net(x).squeeze(-1)

def fit_second_stage_mlp(ztr,ytr,zva,yva,tr,va):
    torch.manual_seed(SEED)
    net=GRUSecondStageMLP(ztr.shape[1]).to(DEVICE)
    opt=torch.optim.Adam(net.parameters(),lr=1e-3,weight_decay=1e-4)
    train_loader=DataLoader(TensorDataset(torch.from_numpy(ztr),torch.from_numpy(ytr),torch.from_numpy(tr.current_price.to_numpy(dtype=np.float32)),torch.from_numpy(tr.future_price.to_numpy(dtype=np.float32))),batch_size=64,shuffle=False)
    best=float('inf'); state=None;bad=0
    for ep in range(DL_EPOCHS):
        net.train()
        for xb,yb,cp,fp in train_loader:
            xb,yb=xb.to(DEVICE),yb.to(DEVICE)
            opt.zero_grad();loss=supervised_loss(net(xb),yb,cp.to(DEVICE),fp.to(DEVICE))
            loss.backward();nn.utils.clip_grad_norm_(net.parameters(),1.0);opt.step()
        pred=predict_second_stage_mlp(net,zva)
        score=numpy_validation_loss(pred,va)
        if score<best-1e-8:
            best=score;state=copy.deepcopy(net.state_dict());bad=0
        else:
            bad+=1
            if bad >= (4 if FAST_MODE else 8):break
    net.load_state_dict(state)
    return net

def predict_second_stage_mlp(net,z):
    net.eval(); out=[]
    with torch.no_grad():
        for (xb,) in DataLoader(TensorDataset(torch.from_numpy(z)),batch_size=512):
            out.append(net(xb.to(DEVICE)).cpu().numpy())
    return np.concatenate(out)

class FactorVAEEncoder(nn.Module):
    """Unsupervised sequence VAE: flatten 30 x F into a fixed-length vector."""
    def __init__(self, seq_len, n_features, latent_dim=16):
        super().__init__()
        dim=seq_len*n_features
        self.encoder=nn.Sequential(nn.Linear(dim,128),nn.ReLU(),nn.Linear(128,64),nn.ReLU())
        self.mu=nn.Linear(64,latent_dim)
        self.logvar=nn.Linear(64,latent_dim)
        self.decoder=nn.Sequential(nn.Linear(latent_dim,64),nn.ReLU(),nn.Linear(64,128),nn.ReLU(),nn.Linear(128,dim))
    def encode(self,x):
        hidden=self.encoder(x.flatten(start_dim=1))
        return self.mu(hidden),self.logvar(hidden).clamp(-8,8)
    def forward(self,x,sample=True):
        mu,logvar=self.encode(x)
        z=mu+torch.exp(0.5*logvar)*torch.randn_like(mu) if sample else mu
        return self.decoder(z),mu,logvar,z

class TCDiscriminator(nn.Module):
    def __init__(self,latent_dim):
        super().__init__()
        self.net=nn.Sequential(nn.Linear(latent_dim,64),nn.LeakyReLU(0.2),
                               nn.Linear(64,64),nn.LeakyReLU(0.2),nn.Linear(64,2))
    def forward(self,z):return self.net(z)

def permute_latent_dimensions(z):
    return torch.stack([z[torch.randperm(len(z),device=z.device),j]
                        for j in range(z.shape[1])],dim=1)

def factorvae_objective(net,disc,xb,sample=True):
    recon,mu,logvar,z=net(xb,sample=sample)
    reconstruction=nn.functional.mse_loss(recon,xb.flatten(start_dim=1))
    kl=-0.5*torch.mean(torch.sum(1+logvar-mu.square()-logvar.exp(),dim=1))
    logits=disc(z)
    tc=(logits[:,0]-logits[:,1]).mean()
    return FACTOR_RECON_WEIGHT*reconstruction+FACTOR_KL_WEIGHT*kl+FACTOR_TC_WEIGHT*tc

def factorvae_validation_loss(net,disc,x):
    net.eval();disc.eval();scores=[]
    with torch.no_grad():
        for (xb,) in DataLoader(TensorDataset(torch.from_numpy(x)),batch_size=256):
            xb=xb.to(DEVICE)
            scores.append((float(factorvae_objective(net,disc,xb,sample=False)),len(xb)))
    return sum(v*n for v,n in scores)/sum(n for _,n in scores)

def train_factorvae_encoder(xtr,xva):
    """Stage 1: train WITHOUT y labels; checkpoint using validation unsupervised loss."""
    torch.manual_seed(SEED)
    net=FactorVAEEncoder(xtr.shape[1],xtr.shape[2],FACTOR_LATENT_DIM).to(DEVICE)
    disc=TCDiscriminator(FACTOR_LATENT_DIM).to(DEVICE)
    opt=torch.optim.Adam(net.parameters(),lr=1e-3,weight_decay=1e-4)
    opt_d=torch.optim.Adam(disc.parameters(),lr=1e-3)
    loader=DataLoader(TensorDataset(torch.from_numpy(xtr)),batch_size=64,shuffle=False)
    best=float('inf');state=None;bad=0
    for ep in range(DL_EPOCHS):
        net.train();disc.train()
        for (xb,) in loader:
            xb=xb.to(DEVICE)
            # Train discriminator to separate joint z and permuted marginal-product samples.
            if len(xb)>1:
                with torch.no_grad():
                    _,_,_,z_detached=net(xb,sample=True)
                logits_joint=disc(z_detached.detach())
                logits_perm=disc(permute_latent_dimensions(z_detached.detach()))
                labels_joint=torch.zeros(len(xb),dtype=torch.long,device=DEVICE)
                labels_perm=torch.ones(len(xb),dtype=torch.long,device=DEVICE)
                d_loss=0.5*(nn.functional.cross_entropy(logits_joint,labels_joint)+
                            nn.functional.cross_entropy(logits_perm,labels_perm))
                opt_d.zero_grad();d_loss.backward();opt_d.step()
            # Update only FactorVAE (encoder + decoder) while discriminator is fixed.
            for p in disc.parameters():p.requires_grad_(False)
            loss=factorvae_objective(net,disc,xb,sample=True)
            opt.zero_grad();loss.backward();nn.utils.clip_grad_norm_(net.parameters(),1.0);opt.step()
            for p in disc.parameters():p.requires_grad_(True)
        score=factorvae_validation_loss(net,disc,xva)
        if np.isfinite(score) and score<best-1e-8:
            best=score;state=copy.deepcopy(net.state_dict());bad=0
        else:
            bad+=1
            if bad>=(4 if FAST_MODE else 8):break
    if state is None:raise RuntimeError('FactorVAE pretraining failed; check features')
    net.load_state_dict(state)
    for p in net.parameters():p.requires_grad_(False)
    for p in disc.parameters():p.requires_grad_(False)
    net.eval();disc.eval()
    return net

def extract_factorvae(net,x):
    """Frozen deterministic 16D posterior mean, never stochastic z at inference."""
    net.eval();pieces=[]
    with torch.no_grad():
        for (xb,) in DataLoader(TensorDataset(torch.from_numpy(x)),batch_size=512):
            mu,_=net.encode(xb.to(DEVICE))
            pieces.append(mu.cpu().numpy())
    return np.concatenate(pieces).astype(np.float32)




# ========================================================================
# Part 15: Walk-forward training and evaluation
# ========================================================================
def run_extra_hybrids():
    global extra_hybrid_models
    extra_hybrid_models={}
    if RUN_EXTRA_HYBRIDS:
        for h in HORIZONS:
            (xtr,ytr,tr),(xva,yva,va),(xte,yte,te)=build_sequences(h)
            # Stage 1: supervised GRU pretraining and explicit parameter freezing.
            gru_encoder=train_gru_encoder(xtr,ytr,xva,yva,tr,va)
            assert not any(p.requires_grad for p in gru_encoder.parameters())
            ztr,zva,zte=(extract_gru(gru_encoder,x) for x in (xtr,xva,xte))
            assert ztr.shape[1]==EXTRA_HIDDEN
            # Stage 2A: independent MLP trained on frozen GRU factors only.
            gru_mlp=fit_second_stage_mlp(ztr,ytr,zva,yva,tr,va)
            record('GRU+MLP',h,'validation',va,predict_second_stage_mlp(gru_mlp,zva))
            record('GRU+MLP',h,'test',te,predict_second_stage_mlp(gru_mlp,zte))
            extra_hybrid_models[('GRU+MLP',h)]=(gru_encoder,gru_mlp)
            # Stage 2B: independent XGBoost trained on same frozen GRU factors.
            candidates=[(2,150)] if FAST_MODE else [(2,300),(3,300),(4,500)]
            best=None
            for depth,trees in candidates:
                candidate=XGBRegressor(n_estimators=trees,max_depth=depth,learning_rate=0.035,
                                       subsample=0.85,colsample_bytree=0.85,reg_lambda=8.0,
                                       objective='reg:squarederror',random_state=SEED,n_jobs=4)
                candidate.fit(ztr,ytr)
                score=evaluate('GRU+XGBoost',h,'validation',va,candidate.predict(zva))[0]['RMSE']
                if best is None or score<best[0]:best=(score,candidate)
            gru_xgb=best[1]
            record('GRU+XGBoost',h,'validation',va,gru_xgb.predict(zva))
            record('GRU+XGBoost',h,'test',te,gru_xgb.predict(zte))
            extra_hybrid_models[('GRU+XGBoost',h)]=(gru_encoder,gru_xgb)
            # Stage 1: FactorVAE unsupervised pretraining (NO target labels).
            factor_encoder=train_factorvae_encoder(xtr,xva)
            assert not any(p.requires_grad for p in factor_encoder.parameters())
            ftr,fva,fte=(extract_factorvae(factor_encoder,x) for x in (xtr,xva,xte))
            assert ftr.shape[1]==FACTOR_LATENT_DIM
            # Stage 2: independent supervised MLP on 16D frozen factors only.
            factor_head=fit_second_stage_mlp(ftr,ytr,fva,yva,tr,va)
            record('FactorVAE+MLP',h,'validation',va,predict_second_stage_mlp(factor_head,fva))
            record('FactorVAE+MLP',h,'test',te,predict_second_stage_mlp(factor_head,fte))
            extra_hybrid_models[('FactorVAE+MLP',h)]=(factor_encoder,factor_head)
            print(f'h={h}: GRU latent={ztr.shape}, FactorVAE latent={ftr.shape}; encoders frozen')



# ============================================================================
# Run expanding walk-forward folds
# ============================================================================


# ========================================================================
# Part 16: Pool predictions and calculate fair metrics
# ========================================================================
# ============================================================
# Walk-forward: all models are retrained independently in each fold.
# Validation and test each cover one calendar year. Expanding train by default.
# ============================================================
all_fold_metrics=[]
all_fold_predictions=[]
fold_summary=[]
for fold_id,(train_end,val_end,test_end) in enumerate(FOLD_CONFIG,1):
    CURRENT_FOLD=fold_id
    TRAIN_END=pd.Timestamp(train_end)
    VAL_END=pd.Timestamp(val_end)
    TEST_END=pd.Timestamp(test_end)
    FOLD_TRAIN_START = (TRAIN_END-pd.DateOffset(years=TRAIN_WINDOW_YEARS)+pd.Timedelta(days=1)
                        if TRAIN_WINDOW_YEARS is not None else None)
    FOLD_DIR=OUTPUT_DIR/f'fold_{fold_id:02d}'
    FOLD_DIR.mkdir(parents=True,exist_ok=False)
    # Reinitialize all results, models, and fold seed.
    random.seed(SEED);np.random.seed(SEED);torch.manual_seed(SEED)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(SEED)
    all_metrics=[];all_predictions=[]
    sizes={}
    for h in HORIZONS:
        tr,va,te=make_dataset(h)
        sizes[h]=(len(tr),len(va),len(te))
        if min(sizes[h])<=0:
            raise ValueError(f'Fold {fold_id}, h={h} has empty split: {sizes[h]}')
    print(f'\n===== FOLD {fold_id}: train <= {TRAIN_END.date()}, '
          f'val <= {VAL_END.date()}, test <= {TEST_END.date()} =====')
    print('Samples (train, val, test):',sizes)
    run_baselines()
    run_tabular_models()
    if RUN_ARIMA:run_arima()
    if RUN_DEEP_LEARNING:run_neural_models()
    if RUN_LSTM_XGBOOST:run_lstm_xgboost()
    if RUN_EXTRA_HYBRIDS:run_extra_hybrids()
    metrics=pd.DataFrame(all_metrics)
    predictions=pd.concat(all_predictions,ignore_index=True)
    metrics.to_csv(FOLD_DIR/'metrics.csv',index=False)
    predictions.to_csv(FOLD_DIR/'predictions.csv',index=False)
    # Fair common-date comparisons, per fold and horizon.
    fair_rows=[]
    for (h,split),g in predictions.groupby(['horizon','split']):
        date_sets=[set(dd.Date) for _,dd in g.groupby('model')]
        common=set.intersection(*date_sets) if date_sets else set()
        for model,dd in g[g.Date.isin(common)].groupby('model'):
            if len(dd)==0:continue
            actual=dd.actual_price.to_numpy()
            pred=dd.predicted_price.to_numpy()
            fair_rows.append({'fold':fold_id,'horizon':h,'split':split,'model':model,
                              'n_common':len(dd),'MAE':mean_absolute_error(actual,pred),
                              'MSE':mean_squared_error(actual,pred),
                              'RMSE':np.sqrt(mean_squared_error(actual,pred)),
                              'Direction_Accuracy':np.mean(np.sign(actual-dd.current_price.to_numpy())==
                                                           np.sign(pred-dd.current_price.to_numpy()))})
    fair=pd.DataFrame(fair_rows)
    fair.to_csv(FOLD_DIR/'fair_metrics.csv',index=False)
    fold_summary.append({'fold':fold_id,'train_start':str(FOLD_TRAIN_START.date()) if FOLD_TRAIN_START is not None else str(raw_target.index.min().date()),
                         'train_end':train_end,'val_end':val_end,'test_end':test_end,
                         'target_mode':TARGET_MODE,'sample_sizes':{str(k):v for k,v in sizes.items()}})
    all_fold_metrics.append(metrics)
    all_fold_predictions.append(predictions)
    print('Fold complete:',fold_id,'| test predictions:',len(predictions[predictions.split=='test']))

metrics=pd.concat(all_fold_metrics,ignore_index=True)
predictions=pd.concat(all_fold_predictions,ignore_index=True)
metrics.to_csv(OUTPUT_DIR/'walkforward_metrics_by_fold.csv',index=False)
predictions.to_csv(OUTPUT_DIR/'walkforward_predictions.csv',index=False)
(OUTPUT_DIR/'walkforward_folds.json').write_text(json.dumps(fold_summary,indent=2),encoding='utf-8')
print('All folds finished. Results:',OUTPUT_DIR)



# ============================================================================
# Pooled fair metrics and stability
# ============================================================================


# ========================================================================
# Part 17: Volatility regime evaluation
# ========================================================================
# Compare models on identical test dates within each fold/horizon,
# then pool all non-overlapping calendar-year test folds.
test=predictions[predictions.split=='test'].copy()
common_parts=[]
for (fold,h),g in test.groupby(['fold','horizon']):
    date_sets=[set(d.Date) for _,d in g.groupby('model')]
    common=set.intersection(*date_sets) if date_sets else set()
    common_parts.append(g[g.Date.isin(common)])
pooled_common=pd.concat(common_parts,ignore_index=True)
rows=[]
for (h,model),g in pooled_common.groupby(['horizon','model']):
    a=g.actual_price.to_numpy();p=g.predicted_price.to_numpy();c=g.current_price.to_numpy()
    rows.append({'horizon':h,'model':model,'n':len(g),
                 'MSE':mean_squared_error(a,p),'MAE':mean_absolute_error(a,p),
                 'RMSE':np.sqrt(mean_squared_error(a,p)),
                 'Direction_Accuracy':np.mean(np.sign(a-c)==np.sign(p-c))})
pooled=pd.DataFrame(rows).sort_values(['horizon','RMSE'])
pooled.to_csv(OUTPUT_DIR/'walkforward_pooled_fair_metrics.csv',index=False)
# Fold-level RMSE variability uses within-fold common origins.
fold_rows=[]
for (fold,h,model),g in pooled_common.groupby(['fold','horizon','model']):
    fold_rows.append({'fold':fold,'horizon':h,'model':model,'n':len(g),
                      'RMSE':np.sqrt(mean_squared_error(g.actual_price,g.predicted_price))})
fold_fair=pd.DataFrame(fold_rows)
fold_fair.to_csv(OUTPUT_DIR/'walkforward_fair_metrics_by_fold.csv',index=False)
stability=fold_fair.groupby(['horizon','model'],as_index=False).agg(
    folds=('fold','nunique'),RMSE_mean=('RMSE','mean'),RMSE_std=('RMSE','std'),
    RMSE_min=('RMSE','min'),RMSE_max=('RMSE','max'))
stability.to_csv(OUTPUT_DIR/'walkforward_stability.csv',index=False)
print('Pooled common-date test comparison (USD/bbl):')
display(pooled.round(4))
print('Across-fold stability:')
display(stability.round(4))



# ============================================================================
# Volatility regimes and run manifest
# ============================================================================


# ========================================================================
# Part 18: Finalize and export evaluation outputs
# ========================================================================
# High/low volatility evaluated using each fold's TRAIN-only threshold.
vol=raw_target.diff().rolling(20,min_periods=20).std(ddof=0)
regime_rows=[]
for meta in fold_summary:
    fold=int(meta['fold']); cutoff=pd.Timestamp(meta['train_end'])
    threshold=vol.loc[:cutoff].median()
    sub=pooled_common[pooled_common.fold==fold].copy()
    sub['historical_vol']=sub.Date.map(vol)
    sub['regime']=np.where(sub.historical_vol.isna(),None,
                           np.where(sub.historical_vol>=threshold,'High volatility','Low volatility'))
    for (h,model,rg),g in sub.dropna(subset=['regime']).groupby(['horizon','model','regime']):
        if len(g)<10:continue
        regime_rows.append({'fold':fold,'horizon':h,'model':model,'regime':rg,
                            'n':len(g),'RMSE':np.sqrt(mean_squared_error(g.actual_price,g.predicted_price)),
                            'MAE':mean_absolute_error(g.actual_price,g.predicted_price)})
regime_metrics=pd.DataFrame(regime_rows)
regime_metrics.to_csv(OUTPUT_DIR/'walkforward_regime_metrics.csv',index=False)
manifest={'target':TARGET,'target_mode':TARGET_MODE,'horizons':HORIZONS,'folds':fold_summary,
          'rolling_window':ROLLING_WINDOW,'lookback':LOOKBACK,'fast_mode':FAST_MODE,
          'feature_count':len(FEATURE_COLUMNS),'feature_groups':ACTIVE_GROUPS,
          'train_window_years':TRAIN_WINDOW_YEARS,
          'external_data_lag_WTI_rows':0,
          'warning':'Same-date alignment does not establish actual publication-time availability.'}
(OUTPUT_DIR/'run_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('Finished. Outputs:',OUTPUT_DIR)

